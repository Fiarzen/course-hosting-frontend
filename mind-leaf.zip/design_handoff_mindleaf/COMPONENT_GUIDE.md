# Component porting guide

One section per file. Each lists the **real** imports/API calls to preserve (verified
against `course-hosting-frontend/src`), the visual target, and the exact copy used in
the prototype. Pair this with the runnable prototype in `design-reference/mindleaf.html`
— open it and click through via the Tweaks panel's "Quick jump" buttons.

Shared imports you'll add to most files:
```js
import { Leaf, BrandLeaf, LeafRow, GrowingStem, MiniStem,
         Kicker, SectionHeading, LeafTag, Field } from './Leaf';
// (from components, the path is './Leaf'; from App it's './components/Leaf')
```

Global restyle rules (apply to every file):
- Replace `bg-white shadow-md rounded-lg` → `ml-card` (or `bg-paper-2 border border-hair rounded-md`).
- Replace `text-gray-900/800` → `text-ink`; `text-gray-600/500` → `text-ink-soft`; `text-gray-400` → `text-ink-faint`.
- Replace `bg-indigo-600 hover:bg-indigo-700 text-white …` buttons → `ml-button-primary`.
- Secondary/cancel buttons → `ml-button-ghost`.
- Inputs `shadow appearance-none border rounded …` → `ml-input` (underline style).
- Section labels / overlines → `<Kicker>…</Kicker>`.
- Headings → `font-serif` with tight tracking.
- Keep all `onClick`, `onChange`, `disabled`, `name=` attributes and handler logic verbatim.

---

## App.jsx  ✅ pre-ported in `reference-ports/App.jsx`

**Preserve:** all `<Route>`s exactly (`/`, `/courses`, `/courses/:courseId`,
`/courses/:courseId/lessons/:lessonId`, `/courses/:courseId/lessons/:lessonId/edit`,
`/lessons`, `/users`, `/login`, `/register`, `/profile`, `/courses/create`,
`/lessons/create`, `/my-courses`, `/reset-password`, `/forgot-password`,
`/verify-email`, `/payment/success`, `/payment/cancel`). Keep `useAuth()` and the
role-gated nav links.

**New:** the `.ml-nav` sticky bar with `BrandLeaf` + "mindleaf" wordmark, underlined
active link, a **ThemeToggle** (leaf knob; persists to `localStorage.theme`, toggles
`.dark` on `<html>`), avatar initial when authed, and a quiet footer. Mobile menu
preserved. Nav labels are lowercase: home / courses / library (=`/profile`) / studio
(=`/my-courses`, CREATOR+ADMIN) / people (=`/users`, ADMIN).

---

## Home.jsx  ✅ pre-ported in `reference-ports/Home.jsx`

No data/API. Three sections: (1) hero — `clamp(48px,7vw,96px)` serif headline
"A quieter place / to learn one thing / at a time.", subhead, two CTAs (→`/courses`,
→`/register`), one giant `Leaf size={360}` at 10% opacity as anchor; (2) three
principles (i/ii/iii, serif numerals); (3) featured-course card linking to `/courses`
with a hatch+leaf cover placeholder. Copy is in the ported file.

---

## Courses.jsx  ✅ pre-ported in `reference-ports/Courses.jsx`

**Preserve every handler and API call:**
- `coursesApi.getAll()`; if authed, `enrollmentApi.getMyCourses()` → `Set` of enrolled ids.
- `handleEnroll` → `enrollmentApi.enrollInCourse(id)` with the exact 409 / 403-allowlist / generic alert branches.
- `handleBuyNow` → `paymentsApi.createCheckoutSession(id)`, set `sessionStorage.stripeCheckout`, redirect to `checkoutUrl`.
- `handlePayPal` → `paymentsApi.createPaypalOrder(id)`, redirect to `approvalUrl`.
- `ALREADY_ENROLLED` code handling on both.
- `formatPrice(course.priceCents, course.currency)`; free when `!course.isPaid`.

**Visual:** editorial header with `{courses.length} courses, attended to slowly.`,
single-line filter bar (all / free / studio) where the active filter shows a small
`<Leaf>` and a mono count; hairline `CourseCard` grid (`auto-fill, minmax(320px,1fr)`).
Card has a corner leaf, mono "N lessons" kicker, serif title (links to
`/courses/:id`), description, and a footer with author + price + the enroll/buy
buttons. Loading → small `<Leaf>` instead of the indigo spinner. New-course button in
header for CREATOR/ADMIN.

---

## CourseDetail.jsx  ✅ pre-ported in `reference-ports/CourseDetail.jsx`  — flagship screen

**Preserve:** `coursesApi.getAll()`+find by `parseInt(courseId)`;
`lessonsApi.getByCourse(courseId)`; if authed: `checkEnrollment()` via
`enrollmentApi.getMyCourses()`, `loadProgress()` via
`enrollmentApi.getCourseProgress(courseId)` (map `lp.lesson.id → lp.completed`),
`loadPaymentStatus()` via `paymentsApi.getPaymentStatus`. Keep `handleEnroll`,
`handleBuyNow`, `handlePayPal`, and `handleCompleteLesson` (which calls
`enrollmentApi.completeLesson(lessonId)` then `playCompletionSound()` then reloads
progress). Keep the `canEnrollDirectly` / `hasPendingPurchase` / `isAuthorOrAdmin`
gating.

**Visual target:**
- Two-column header: left = mono kicker (`N lessons`), `clamp(40px,6vw,76px)` serif
  title, description; right = author, tuition (serif price or "free"), and the
  enroll/buy controls (card+PayPal when paid & not entitled, single "begin/enroll"
  when free or entitled), plus a `LeafTag` "tending — x of y" when enrolled.
- Body grid `[160px 1fr]`: **left is a sticky `<GrowingStem>`** built from
  `lessons.map(l => ({ id, title, done: !!lessonProgress[l.id] }))`, with a "growth"
  kicker above and `completed/total` below; clicking a leaf sets the highlighted
  lesson (`currentIndex`). Right is the lesson list — each row: mono index, serif
  title, content (gated for non-enrolled), a "mark complete"/"completed" leaf toggle,
  and "open →" to the lesson route. The current row gets a `--moss-wash` tint; each
  row shows a leaf that fills when completed.
- The growing stem **is the progress bar** — there is no separate bar here.

---

## LessonView.jsx  (not pre-ported — build from prototype `LessonScreen`)

**Preserve:** `useParams()` → `courseId`, `lessonId`; `lessonsApi.getById(lessonId)`
(and/or `getByCourse`); whatever enroll/complete logic the current file uses
(`enrollmentApi.completeLesson`, `playCompletionSound`). Keep video embed + PDF
rendering wiring and `LessonView.css` if still needed.

**Visual target (prototype `LessonScreen`):** max-width ~1080; header with "←
{course title}" back link and a `LeafRow` showing course progress (clickable to switch
lessons); a 16:9 `--paper-2` panel with hatch fill + a circular play button as the
video placeholder; mono "Lesson NN · M min" kicker; ~52px serif title; body copy at
18px/1.7; a footer row with a prominent **mark-complete** button (fills with moss +
"lesson complete" when done) and prev/next; finally a PDF-notes row (leaf + title +
"open pdf →"). Swap the placeholders for the real video/PDF.

---

## Login.jsx  (build from prototype `SignInScreen`)

**Preserve:** `useAuth().login(email, password)`, the `result.success` →
`navigate('/')` branch (prototype sends to `/library`; **keep the app's `/`**), error
state, the required-fields guard, `<Link to="/forgot-password">` and
`<Link to="/register">`.

**Visual:** `AuthShell` — two columns. Left: `Kicker` "welcome back", serif "Sign in",
intro line, then `<Field>`-wrapped `ml-input`s for email + password (the password
Field's `hint` is the forgot-password link), an `ml-button-primary` submit, and a link
to register. Right: `<AuthLeafComposition>` (a `GrowingStem` + tagline) — reproduce
from `design-reference/screens-auth.jsx`. Drop the indigo card/shadow.

---

## Register.jsx  (build from prototype `RegisterScreen`)

**Preserve:** local `formData {name,email,password,confirmPassword}`, `validateForm`
(password ≥ 6, match, email regex — keep the **6**-char rule from the real file, not
the prototype's "8"), `usersApi.register({ name||undefined, email, password })`,
`success` state + 2s redirect to `/`, 409 handling.

**Visual:** same `AuthShell`. Fields: name (optional), email, password, confirm
password. The learner/teacher segmented control in the prototype is **decorative** —
only wire it if registration accepts a role; otherwise omit or leave it visual.
Success → a moss confirmation panel ("Account created — check your inbox…"). Keep the
"Already have an account? sign in" link.

---

## ForgotPassword.jsx  (build from prototype `ForgotPasswordScreen`)

**Preserve:** `authApi.forgotPassword(email)`, `submitted` state, the 1-hour-expiry
copy, error handling, back-to-login link.

**Visual:** `AuthShell`; pre-submit = email `Field` + `ml-button-primary` "send reset
link"; post-submit = a `--moss-wash` panel with a leaf and "A reset link is on its way
to {email}" + a ghost "back to sign in". The right composition's stem can show "more
grown" after submit (a nice touch, optional).

---

## Profile.jsx  (build from prototype `ProfileScreen2`)

**Preserve everything:** `useAuth()` (redirect to `/login` if not authed),
`enrollmentApi.getMyCourses()`, the **email-verification banner** (`user.emailVerified`
+ `authApi.resendVerification()`), `handleUnenroll` (confirm + `unenrollFromCourse`),
the **progress modal** (`handleViewProgress` → `getCourseProgress`,
`handleCompleteLesson`). These are real features — keep them.

**Visual:** header with avatar (initial), `Kicker` "account · {role}", serif name,
email + "member since". Stats row (4): leaves unfurled (sum of completed across
enrollments), courses tending, courses finished, reading minutes. In-progress section
= cards with `LeafRow`; finished section = hairline list with `LeafTag` "complete".
Restyle the modal to paper/hairline; you may render its per-lesson list with leaf
check-marks. Keep the unenroll + mark-complete buttons (restyled).

> Note: the app has **two** profile concepts — keep the real data shape
> (`enrollment.course.*`, `enrollment.completedLessons/totalLessons/progress`,
> `enrollment.enrolledAt`). The prototype's `COURSES` mock is illustrative only.

---

## MyCourses.jsx  (build from prototype `MyCoursesScreen`)

**Preserve all management logic** — this is the densest file:
`coursesApi.getMyCreated()`, per-course lesson loading (`lessonsApi.getByCourse`),
reordering (`handleMoveLesson` + `lessonsApi.reorderForCourse`), delete lesson/course,
**access control** (`coursesApi.updateAccess`, allowlist textarea), **pricing**
(`paymentsApi.updatePricing`, `CURRENCY_OPTIONS`, the `getPricingForm` logic), and all
the per-id `saving*`/`deleting*` busy maps. Role guard: CREATOR/ADMIN only.

**Visual:** "studio · creator" kicker, serif "Your courses", a `new course` primary
button (→`/courses/create`), published/drafts tabs, and a **hairline table** (course /
state / enrolled / lessons / last edited / open). State = `LeafTag` "published" vs an
outlined "draft" pill. Keep the access + pricing panels and the lesson manager — just
restyle them to the paper/hairline system (cards → `ml-card`, the green/indigo/amber
buttons → `ml-button-primary`/`ghost`, checkboxes/selects keep function). The
prototype's table is the look; your real file has more controls — keep them all,
restyled.

---

## CreateCourse.jsx  (build from prototype `CreateCourseScreen`)

**Preserve:** `formData {title,description,restrictedToAllowList,allowedEmailsText,
isPaid,priceInput,currency}`, the email-parse + `priceCents = Math.round(parsed*100)`
logic, `coursesApi.create({ …, authorId: user?.id, allowedEmails, isPaid, priceCents,
currency })`, redirect to `/courses`, error state. CREATOR/ADMIN only.

**Visual:** two columns. Left = calm form (`Field` + `ml-input`/textarea), a season
segmented control (prototype only — **omit if the model has no season field**),
free/paid toggle, conditional price + `CURRENCY_OPTIONS` select, and the
allowlist textarea when restricted. Right = a **live preview** `CourseCard` updating
from `title`/`description`/`isPaid`/`price` as the user types. Primary "save and
continue" + ghost "save as draft" (if your API has no draft state, make both submit, or
drop the ghost).

---

## Users.jsx  (build from prototype `UsersScreen`)

**Preserve:** ADMIN guard; `usersApi.getAll()` (handle array-or-`.data`);
`handleUpgradeToCreator` (`upgradeUserToCreator`), `handleResetPassword`
(`usersApi.resetPassword` → build `/reset-password?token=…` and `window.prompt` it),
`handleDeleteUser` (`deleteUser`, with the "can't delete admins / self" guards). Keep
the busy maps.

**Visual:** "studio · admin" kicker, serif "People in the garden.", a filter row
(all / students / creators / admins with mono counts) + a search field, and a hairline
table (person w/ avatar initial + email / role / joined / courses / lessons / actions).
Use a `RolePill` (admin = filled moss-ish, creator = wash, student = outlined). Action
buttons restyle to small ghost/primary; keep their exact handlers. Your real user
objects may not have `since/courses/lessons` counts — show what exists, drop columns
that don't (don't fabricate data).

---

## PaymentSuccess.jsx  (build from prototype `PaymentSuccessScreen`)

**Preserve the entire flow:** `useSearchParams()` → `session_id` (Stripe) vs `token`
(PayPal); `sessionStorage.stripeCheckout` read for `courseId`; PayPal
`capturePaypalOrder` then poll; Stripe poll of `getPaymentStatus` up to `MAX_POLLS=10`
every `POLL_INTERVAL_MS=2000`; the five states `capturing | loading | enrolled |
pending | error`. Keep all links (`/courses/:id`, `/profile`).

**Visual:** replace the 🎉 with the **all-leaves-filled stem** SVG from the prototype
(`PaymentSuccessScreen`). "payment received" kicker, serif "You're enrolled.",
thank-you line with the course title, primary "begin the course" + ghost "go to your
library". The loading/capturing states: swap the indigo/blue spinner for a small
`<Leaf>` mark + the same status text. Pending/error states: restyle to paper, keep copy
intent.

---

## PaymentCancel.jsx  (build from prototype `PaymentCancelScreen`)

**Preserve:** `sessionStorage.stripeCheckout` read for `courseId`, retry links
(`/courses/:id`, `/courses`).

**Visual:** the **dashed empty stem** with outlined (unfilled) leaves. "payment not
completed" kicker, serif "No leaves planted.", "Your card was not charged…" line,
primary "try again" + ghost "back to catalogue".

---

## Quick QA checklist

- [ ] App compiles; fonts (Shippori Mincho / DM Sans / DM Mono) actually load.
- [ ] Dark mode toggles via `.dark` on `<html>` and persists across reload.
- [ ] No `indigo`/`gray`/`emerald` utility colors or `shadow-md` remain in restyled files.
- [ ] Leaves in `LeafRow`/`GrowingStem`/`MiniStem` are connected to the stem (petioles + grown segment + bud).
- [ ] Course Detail shows the sticky GrowingStem and a leaf fills when you mark a lesson complete (and the completion sound still plays).
- [ ] Stripe + PayPal checkout still redirect; PaymentSuccess still polls and enrolls.
- [ ] Role gating intact: studio (CREATOR/ADMIN), people (ADMIN).
- [ ] `formatPrice` used for all prices (GBP/USD/EUR); no hard-coded ¥ from the prototype.
- [ ] Email-verify banner, unenroll, progress modal, allowlist + pricing editors all still work.
