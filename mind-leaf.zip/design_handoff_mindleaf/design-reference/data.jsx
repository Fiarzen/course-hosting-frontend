// data.jsx — mock data for the mindleaf prototype.

const COURSES = [
  {
    id: 1,
    title: "The art of slow reading",
    subtitle: "On staying with a single page",
    description:
      "A six-week practice in attention. Inhabit a page longer than is comfortable, and notice what you would otherwise have missed.",
    author: "Ren Asano",
    authorRole: "Essayist, Kyoto",
    lessons: 8,
    minutes: 6,
    price: null,
    completed: 3,
    season: "Spring",
    color: "moss",
  },
  {
    id: 2,
    title: "Foundations of a quiet practice",
    subtitle: "Beginner course",
    description:
      "A field guide to attention — how to gather it, how to lose it gently, and how to return.",
    author: "Mira Holt",
    authorRole: "Teacher",
    lessons: 12,
    minutes: 9,
    price: null,
    completed: 12,
    season: "Summer",
    color: "moss",
  },
  {
    id: 3,
    title: "Botany for the curious",
    subtitle: "A walking course",
    description:
      "Names, shapes, and lives of the plants that share your daily walk. Field-built, slowly.",
    author: "Jonas Vree",
    authorRole: "Field botanist",
    lessons: 14,
    minutes: 12,
    price: 4900,
    completed: 0,
    season: "Summer",
    color: "moss",
  },
  {
    id: 4,
    title: "Letters from a single woodland",
    subtitle: "Field notes",
    description:
      "Twelve months spent listening to one small forest. Composed as letters to a friend who never visits.",
    author: "Imogen Park",
    authorRole: "Writer",
    lessons: 6,
    minutes: 14,
    price: null,
    completed: 6,
    season: "Autumn",
    color: "gold",
  },
  {
    id: 5,
    title: "Kintsugi for the everyday",
    subtitle: "Mending as a discipline",
    description:
      "Mending objects, habits, and attention. With gold lacquer, when possible. With patience, always.",
    author: "Hiro Tanaka",
    authorRole: "Craftsman",
    lessons: 9,
    minutes: 18,
    price: 8900,
    completed: 0,
    season: "Winter",
    color: "gold",
  },
  {
    id: 6,
    title: "Walking as a practice",
    subtitle: "The simplest discipline",
    description:
      "A field manual for the oldest practice we have. One foot, then the other. Then again.",
    author: "Ren Asano",
    authorRole: "Essayist, Kyoto",
    lessons: 5,
    minutes: 8,
    price: null,
    completed: 2,
    season: "Spring",
    color: "moss",
  },
];

const LESSONS = {
  1: [
    { id: 11, title: "Why slowing down is difficult", minutes: 5, done: true,
      excerpt: "We begin with the obstacle: the mind moves faster than the page. The first practice is to notice that, without judgment, and then begin again." },
    { id: 12, title: "The first reading: orientation", minutes: 6, done: true,
      excerpt: "A single page, read three times. The first time is for the eyes. The second for the ear. The third for the room you read it in." },
    { id: 13, title: "Marking and not-marking", minutes: 7, done: true,
      excerpt: "Underlining is a form of attention. So is leaving the page alone. We try both for a week, and notice what changes." },
    { id: 14, title: "Reading aloud, slowly", minutes: 5, done: false,
      excerpt: "The voice is older than the eye. Even when reading alone, a quiet voice changes what we notice." },
    { id: 15, title: "Walking with a sentence", minutes: 8, done: false,
      excerpt: "Carry a single sentence on a walk. Return to it as you would a small companion." },
    { id: 16, title: "Returning to the same page", minutes: 6, done: false,
      excerpt: "The page does not change. We do. The practice this week is to return to one page each morning for seven days." },
    { id: 17, title: "Silence around the page", minutes: 4, done: false,
      excerpt: "Reading is also listening. Try a page in three different rooms." },
    { id: 18, title: "A small ceremony, ending", minutes: 5, done: false,
      excerpt: "How to finish a book. How to put it down. How to remember it without rereading." },
  ],
};

// Fallback: synthesize a lesson list for any course we didn't hand-write.
function lessonsFor(courseId) {
  if (LESSONS[courseId]) return LESSONS[courseId];
  const c = COURSES.find((x) => x.id === courseId);
  if (!c) return [];
  return Array.from({ length: c.lessons }).map((_, i) => ({
    id: courseId * 100 + i,
    title: `Lesson ${String(i + 1).padStart(2, "0")}`,
    minutes: c.minutes,
    done: i < c.completed,
    excerpt:
      "A single idea, attended to slowly. The lesson is the practice; the practice is the lesson.",
  }));
}

window.COURSES = COURSES;
window.lessonsFor = lessonsFor;
