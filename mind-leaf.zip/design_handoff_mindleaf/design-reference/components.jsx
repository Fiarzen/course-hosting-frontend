// components.jsx — shared visual building blocks for mindleaf.

// ---------------------------------------------------------------
// Leaf glyph — the single motif of the design system. One shape,
// one vein. Reused at every scale.
// ---------------------------------------------------------------
function Leaf({ size = 16, filled = true, tilt = -18, color, style, strokeWidth = 1.4 }) {
  const stroke = color || "currentColor";
  const fill = filled ? (color || "currentColor") : "none";
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={stroke}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ transform: `rotate(${tilt}deg)`, display: "inline-block", verticalAlign: "middle", ...style }}
      aria-hidden="true"
    >
      <path
        d="M12 2 C 5 8, 5 17, 12 22 C 19 17, 19 8, 12 2 Z"
        fill={fill}
      />
      <path d="M12 4 V 21" stroke={color || "var(--paper)"} opacity={filled ? 0.55 : 0.8} />
    </svg>
  );
}

function BrandLeaf({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" style={{ display: "inline-block", verticalAlign: "-2px" }}>
      <path d="M12 2 C 5 8, 5 17, 12 22 C 19 17, 19 8, 12 2 Z" fill="var(--moss)" />
      <path d="M12 4 V 21" stroke="var(--paper)" strokeWidth="1.2" strokeLinecap="round" opacity="0.7" />
    </svg>
  );
}

// ---------------------------------------------------------------
// Nav
// ---------------------------------------------------------------
function Nav({ current, onNavigate, isAuthed, onToggleAuth, dark, onToggleDark }) {
  const items = [
    { key: "home",    label: "home" },
    { key: "courses", label: "courses" },
    { key: "library", label: "library" },
    { key: "about",   label: "about" },
  ];
  return (
    <nav
      style={{
        position: "sticky", top: 0, zIndex: 20,
        background: "color-mix(in oklab, var(--paper) 88%, transparent)",
        backdropFilter: "blur(10px)",
        WebkitBackdropFilter: "blur(10px)",
        borderBottom: "1px solid var(--hair)",
      }}
    >
      <div style={{ maxWidth: 1240, margin: "0 auto", padding: "18px 40px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24 }}>
        <button onClick={() => onNavigate({ name: "home" })} style={{ display: "flex", alignItems: "center", gap: 9, padding: 0 }}>
          <BrandLeaf size={15} />
          <span className="serif" style={{ fontSize: 20, letterSpacing: "-0.01em", color: "var(--ink)" }}>mindleaf</span>
        </button>

        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          {items.map((it) => {
            const active = current.name === it.key || (it.key === "courses" && (current.name === "course" || current.name === "lesson"));
            return (
              <button
                key={it.key}
                onClick={() => onNavigate({ name: it.key })}
                style={{
                  padding: "10px 16px",
                  fontSize: 14,
                  color: active ? "var(--ink)" : "var(--ink-soft)",
                  position: "relative",
                  letterSpacing: "0.02em",
                }}
              >
                {it.label}
                <span
                  style={{
                    position: "absolute", left: 16, right: 16, bottom: 4, height: 1,
                    background: active ? "var(--moss)" : "transparent",
                    transition: "background 220ms ease",
                  }}
                />
              </button>
            );
          })}
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <ThemeToggle dark={dark} onToggle={onToggleDark} />
          {isAuthed ? (
            <button
              onClick={() => onNavigate({ name: "profile" })}
              style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "var(--ink-soft)" }}
            >
              <span style={{
                width: 28, height: 28, borderRadius: "50%",
                background: "var(--moss-wash)",
                border: "1px solid var(--hair)",
                display: "grid", placeItems: "center",
                color: "var(--moss-deep)", fontSize: 12, fontWeight: 500,
              }}>m</span>
              mira
            </button>
          ) : (
            <button onClick={() => onNavigate({ name: "signin" })} style={{ fontSize: 13, color: "var(--ink-soft)" }}>sign in</button>
          )}
        </div>
      </div>
    </nav>
  );
}

function ThemeToggle({ dark, onToggle }) {
  return (
    <button
      onClick={onToggle}
      aria-label={dark ? "switch to light" : "switch to dark"}
      style={{
        width: 44, height: 24, borderRadius: 24,
        border: "1px solid var(--hair-strong)",
        background: "transparent",
        position: "relative",
        padding: 0,
        transition: "background 220ms ease",
      }}
    >
      <span style={{
        position: "absolute", top: 2, left: dark ? 22 : 2,
        width: 18, height: 18, borderRadius: 18,
        background: dark ? "var(--moss-deep)" : "var(--moss)",
        transition: "left 220ms cubic-bezier(0.4,0.0,0.2,1), background 220ms ease",
        display: "grid", placeItems: "center",
      }}>
        <Leaf size={10} color="var(--paper)" tilt={dark ? 30 : -20} strokeWidth={0} />
      </span>
    </button>
  );
}

// ---------------------------------------------------------------
// LeafRow — horizontal vine. Each leaf attaches to a continuous stem
// via a small petiole. Drawn as a single SVG so leaves are physically
// connected.
// ---------------------------------------------------------------
function LeafRow({ total, completed, size = 18, gap = 10, onLeafClick }) {
  if (total === 0) return null;
  const step = size + gap;
  const padX = size * 0.6;
  const w = step * total + padX * 2 - gap;
  const h = size * 2.6;
  const stemY = h / 2;
  const startX = padX;
  const lastDoneIdx = Math.max(0, completed - 1);
  const grownX = startX + lastDoneIdx * step;

  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      width={w}
      height={h}
      style={{ display: "block", overflow: "visible" }}
      role="img"
      aria-label={`${completed} of ${total} lessons complete`}
    >
      {/* faint full stem */}
      <line x1={startX - 6} y1={stemY} x2={w - padX + 6} y2={stemY}
            stroke="var(--hair-strong)" strokeWidth="1" strokeLinecap="round" />
      {/* grown stem */}
      {completed > 0 && (
        <line x1={startX - 6} y1={stemY} x2={grownX} y2={stemY}
              stroke="var(--moss)" strokeWidth="1.6" strokeLinecap="round" />
      )}
      {completed > 0 && (
        <circle cx={grownX} cy={stemY} r="1.8" fill="var(--moss)" />
      )}

      {Array.from({ length: total }).map((_, i) => {
        const cx = startX + i * step;
        const above = i % 2 === 0;
        const done = i < completed;
        const tilt = above ? -55 - ((i * 5) % 10) : 55 + ((i * 5) % 10);
        const color = done ? "var(--moss)" : "var(--ink-faint)";
        const petEndY = above ? stemY - size * 0.35 : stemY + size * 0.35;
        return (
          <g
            key={i}
            onClick={onLeafClick ? () => onLeafClick(i) : undefined}
            style={{ cursor: onLeafClick ? "pointer" : "default", opacity: done ? 1 : 0.75 }}
          >
            <title>{`Lesson ${i + 1}${done ? " complete" : ""}`}</title>
            <line x1={cx} y1={stemY} x2={cx} y2={petEndY}
                  stroke={color} strokeWidth={done ? 1.1 : 0.9} strokeLinecap="round" />
            <g transform={`translate(${cx} ${petEndY}) rotate(${tilt}) scale(${size / 22})`}>
              <path d="M0 0 C -7 -3, -10 -10, 0 -16 C 10 -10, 7 -3, 0 0 Z"
                    fill={done ? color : "transparent"}
                    stroke={color}
                    strokeWidth={done ? 0 : 1.3} strokeLinejoin="round" />
              <path d="M0 0 V -15" stroke={done ? "var(--paper-2)" : color}
                    strokeWidth="0.8" strokeLinecap="round" opacity={done ? 0.55 : 0.7} />
            </g>
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------
// CourseCard
// ---------------------------------------------------------------
function CourseCard({ course, onOpen, compact = false }) {
  const isPaid = course.price != null;
  const isEnrolled = course.completed > 0 || course.id === 1 || course.id === 2;
  return (
    <article
      onClick={() => onOpen(course.id)}
      style={{
        position: "relative",
        background: "var(--paper-2)",
        border: "1px solid var(--hair)",
        borderRadius: "var(--radius)",
        padding: "var(--card-pad, 32px)",
        cursor: "pointer",
        transition: "border-color 220ms ease, transform 220ms ease",
        minHeight: compact ? 0 : 280,
        display: "flex", flexDirection: "column", justifyContent: "space-between",
      }}
      onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--hair-strong)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--hair)"; }}
    >
      <span style={{ position: "absolute", top: 22, right: 22, opacity: 0.85, color: "var(--moss)" }}>
        <Leaf size={20} tilt={isPaid ? 28 : -22} strokeWidth={0} />
      </span>

      <header>
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ink-faint)", marginBottom: 14 }}>
          {course.season} · {course.lessons} lessons
        </div>
        <h3 className="serif" style={{ fontSize: 26, lineHeight: 1.15, margin: 0, marginBottom: 10, color: "var(--ink)", maxWidth: "85%" }}>
          {course.title}
        </h3>
        <p style={{ margin: 0, color: "var(--ink-soft)", fontSize: 14.5, lineHeight: 1.55, maxWidth: "95%" }}>
          {course.description}
        </p>
      </header>

      <footer style={{ marginTop: 28, paddingTop: 18, borderTop: "1px solid var(--hair)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <span style={{ fontSize: 13, color: "var(--ink)" }}>{course.author}</span>
          <span style={{ fontSize: 11.5, color: "var(--ink-faint)" }}>{course.authorRole}</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          {isEnrolled ? (
            <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--moss-deep)" }}>
              <Leaf size={11} strokeWidth={0} /> tending
            </span>
          ) : null}
          <span className="serif" style={{ fontSize: 18, color: "var(--ink)" }}>
            {isPaid ? `¥${(course.price / 100).toFixed(0)}` : "free"}
          </span>
        </div>
      </footer>
    </article>
  );
}

// ---------------------------------------------------------------
// GrowingStem — vertical, every leaf connects to the stem via a
// curved petiole. Single SVG.
// ---------------------------------------------------------------
function GrowingStem({ lessons, currentIndex, onJump }) {
  const completed = lessons.filter((l) => l.done).length;
  const total = lessons.length;
  const stemLen = 480;
  const startY = 40;
  const step = (stemLen - 80) / Math.max(total - 1, 1);
  const width = 160;
  const stemX = 80;

  const growthIdx = Math.max(currentIndex, completed - 1);
  const tipY = startY + step * Math.max(0, growthIdx);

  return (
    <div style={{ position: "relative", width, height: stemLen + 40 }}>
      <svg
        viewBox={`0 0 ${width} ${stemLen + 40}`}
        width={width}
        height={stemLen + 40}
        style={{ overflow: "visible" }}
      >
        <line x1={stemX} y1={startY - 8} x2={stemX} y2={stemLen}
              stroke="var(--hair-strong)" strokeWidth="1" />
        <line x1={stemX} y1={startY - 8} x2={stemX} y2={tipY + 14}
              stroke="var(--moss)" strokeWidth="1.8" strokeLinecap="round" />
        <line x1={stemX - 12} y1={stemLen + 4} x2={stemX + 12} y2={stemLen + 4}
              stroke="var(--hair-strong)" strokeWidth="1" />
        <circle cx={stemX} cy={tipY + 14} r="3" fill="var(--moss)" />

        {lessons.map((lesson, i) => {
          const y = startY + step * i;
          const done = lesson.done;
          const isCurrent = i === currentIndex;
          const sideSign = i % 2 === 0 ? -1 : 1;
          const active = done || isCurrent;
          const color = done ? "var(--moss)" : (isCurrent ? "var(--moss-deep)" : "var(--ink-faint)");
          const stroke = done ? "var(--moss)" : "var(--ink-faint)";

          const petEndX = stemX + sideSign * 22;
          const petEndY = y - 6;
          const ctrlX = stemX + sideSign * 8;
          const ctrlY = y + 1;

          const leafRot = sideSign * 70;
          const labelX = stemX + sideSign * 56;
          const labelAnchor = sideSign === -1 ? "end" : "start";

          return (
            <g
              key={lesson.id}
              onClick={() => onJump && onJump(i)}
              style={{ cursor: "pointer" }}
            >
              <title>{`${String(i + 1).padStart(2, "0")} - ${lesson.title}`}</title>
              <rect
                x={sideSign === -1 ? stemX - 70 : stemX}
                y={y - 18}
                width="70"
                height="36"
                fill="transparent"
              />
              <path
                d={`M ${stemX} ${y} Q ${ctrlX} ${ctrlY} ${petEndX} ${petEndY}`}
                stroke={active ? stroke : "var(--ink-faint)"}
                strokeWidth={done ? 1.4 : 1}
                fill="none"
                strokeLinecap="round"
                opacity={active ? 1 : 0.55}
              />
              <g transform={`translate(${petEndX} ${petEndY}) rotate(${leafRot}) scale(1.1)`}>
                <path
                  d="M0 0 C -7 -3, -10 -10, 0 -16 C 10 -10, 7 -3, 0 0 Z"
                  fill={active ? color : "transparent"}
                  stroke={color}
                  strokeWidth={active ? 0 : 1.3}
                  strokeLinejoin="round"
                />
                <path d="M0 0 V -15" stroke={active ? "var(--paper-2)" : color}
                      strokeWidth="0.8" strokeLinecap="round" opacity={active ? 0.55 : 0.7} />
              </g>
              <text
                x={labelX}
                y={y + 4}
                textAnchor={labelAnchor}
                fontSize="10"
                fontFamily="DM Mono, monospace"
                letterSpacing="1"
                fill={isCurrent ? "var(--ink)" : "var(--ink-faint)"}
              >
                {String(i + 1).padStart(2, "0")}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function ProgressLabel({ completed, total }) {
  if (total === 0) return null;
  const pct = Math.round((completed / total) * 100);
  return (
    <span className="mono" style={{ fontSize: 11, letterSpacing: "0.12em", color: "var(--ink-faint)" }}>
      {completed}/{total} · {pct}%
    </span>
  );
}

function SectionHeading({ kicker, children, align = "left" }) {
  return (
    <div style={{ marginBottom: 28, textAlign: align }}>
      {kicker && (
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 10, display: "flex", alignItems: "center", gap: 8, justifyContent: align === "center" ? "center" : "flex-start" }}>
          <Leaf size={11} strokeWidth={0} tilt={-22} /> {kicker}
        </div>
      )}
      <h2 className="serif" style={{ margin: 0, fontSize: 36, lineHeight: 1.1, color: "var(--ink)", letterSpacing: "-0.012em" }}>
        {children}
      </h2>
    </div>
  );
}

function LeafScatter({ count = 12, intensity = "subtle" }) {
  if (intensity === "off") return null;
  const opacities = intensity === "lush" ? [0.18, 0.12, 0.08] : [0.07, 0.05, 0.04];
  const positions = [
    [8, 22, 24, -28], [88, 18, 18, 36], [16, 64, 20, 18], [82, 70, 26, -42],
    [40, 8, 14, 12], [55, 90, 22, -10], [72, 42, 16, 50], [22, 86, 18, -60],
    [62, 14, 14, -8], [4, 48, 16, 24], [94, 50, 22, -20], [48, 56, 12, 60],
  ];
  return (
    <div aria-hidden="true" style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden" }}>
      {positions.slice(0, count).map((p, i) => (
        <span key={i} style={{
          position: "absolute",
          left: `${p[0]}%`, top: `${p[1]}%`,
          color: "var(--moss)",
          opacity: opacities[i % opacities.length],
          transform: `rotate(${p[3]}deg)`,
        }}>
          <Leaf size={p[2]} strokeWidth={0} />
        </span>
      ))}
    </div>
  );
}

// Small "paper" form-field components used by Auth / Create screens.
function Field({ label, hint, children, required }) {
  return (
    <label style={{ display: "block", marginBottom: 22 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
        <span className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ink-soft)" }}>
          {label}{required && <span style={{ color: "var(--moss)", marginLeft: 4 }}>·</span>}
        </span>
        {hint && <span style={{ fontSize: 11, color: "var(--ink-faint)" }}>{hint}</span>}
      </div>
      {children}
    </label>
  );
}

function TextInput({ value, onChange, type = "text", placeholder, autoComplete }) {
  return (
    <input
      type={type}
      value={value}
      placeholder={placeholder}
      autoComplete={autoComplete}
      onChange={(e) => onChange && onChange(e.target.value)}
      style={{
        width: "100%",
        background: "transparent",
        border: 0,
        borderBottom: "1px solid var(--hair-strong)",
        padding: "10px 0",
        fontFamily: "'DM Sans', sans-serif",
        fontSize: 16,
        color: "var(--ink)",
        outline: "none",
        transition: "border-color 200ms ease",
      }}
      onFocus={(e) => { e.target.style.borderBottomColor = "var(--moss)"; }}
      onBlur={(e) => { e.target.style.borderBottomColor = "var(--hair-strong)"; }}
    />
  );
}

function PrimaryButton({ children, onClick, disabled, full }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        background: "var(--ink)", color: "var(--paper)",
        padding: "14px 26px", borderRadius: 4,
        fontSize: 14, letterSpacing: "0.04em",
        display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 10,
        width: full ? "100%" : "auto",
        opacity: disabled ? 0.5 : 1,
        cursor: disabled ? "not-allowed" : "pointer",
      }}
    >
      {children}
    </button>
  );
}

function GhostButton({ children, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: "transparent",
        color: "var(--ink-soft)",
        padding: "14px 22px", borderRadius: 4,
        fontSize: 14, letterSpacing: "0.02em",
        border: "1px solid var(--hair-strong)",
        cursor: "pointer",
      }}
    >
      {children}
    </button>
  );
}

// Small badge with a leaf glyph + label (used for course tags, role pills, etc.)
function LeafTag({ children, tone = "moss" }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: "4px 10px",
      borderRadius: 999,
      background: "var(--moss-wash)",
      color: "var(--moss-deep)",
      fontSize: 11,
      letterSpacing: "0.04em",
      border: "1px solid color-mix(in oklab, var(--moss-soft) 60%, transparent)",
    }}>
      <Leaf size={9} strokeWidth={0} tilt={-22} /> {children}
    </span>
  );
}

Object.assign(window, { Leaf, BrandLeaf, Nav, ThemeToggle, LeafRow, CourseCard, GrowingStem, ProgressLabel, SectionHeading, LeafScatter, Field, TextInput, PrimaryButton, GhostButton, LeafTag });
