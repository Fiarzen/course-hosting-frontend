// app.jsx — main App, navigation state, theme + tweaks.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "dark": false,
  "density": "regular",
  "motif": "subtle",
  "accent": "moss"
}/*EDITMODE-END*/;

const ACCENT_PALETTES = {
  moss:   { moss: "#4a6b3f", deep: "#34522c", soft: "#b7c4a4", wash: "#e8ecd9",
            darkMoss: "#9bb787", darkDeep: "#b9d0a5", darkSoft: "#3a4a32", darkWash: "#1c2418" },
  forest: { moss: "#2f4a2a", deep: "#1f3a1c", soft: "#94a988", wash: "#dee5cd",
            darkMoss: "#7aa069", darkDeep: "#a5c293", darkSoft: "#2b3a25", darkWash: "#161e12" },
  sage:   { moss: "#6b8a64", deep: "#506b48", soft: "#c3cfb6", wash: "#ecefdf",
            darkMoss: "#a8c197", darkDeep: "#c3d6b4", darkSoft: "#3f5036", darkWash: "#1f2719" },
  olive:  { moss: "#6a6a2e", deep: "#4d4d1e", soft: "#c2c194", wash: "#ecead2",
            darkMoss: "#bdbf7b", darkDeep: "#d4d49b", darkSoft: "#46461f", darkWash: "#1d1d10" },
};

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [view, setView] = React.useState({ name: "home" });
  const [isAuthed, setIsAuthed] = React.useState(true);

  // Apply theme + density + accent to <html> at runtime
  React.useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", !!t.dark);
    root.setAttribute("data-density", t.density || "regular");

    const pal = ACCENT_PALETTES[t.accent] || ACCENT_PALETTES.moss;
    if (t.dark) {
      root.style.setProperty("--moss", pal.darkMoss);
      root.style.setProperty("--moss-deep", pal.darkDeep);
      root.style.setProperty("--moss-soft", pal.darkSoft);
      root.style.setProperty("--moss-wash", pal.darkWash);
    } else {
      root.style.setProperty("--moss", pal.moss);
      root.style.setProperty("--moss-deep", pal.deep);
      root.style.setProperty("--moss-soft", pal.soft);
      root.style.setProperty("--moss-wash", pal.wash);
    }
  }, [t.dark, t.density, t.accent]);

  // Reset scroll on navigation
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [view.name, view.id, view.lessonIndex]);

  const renderView = () => {
    switch (view.name) {
      case "home":
        return <HomeScreen onNavigate={setView} motifIntensity={t.motif} />;
      case "courses":
        return <CoursesScreen onNavigate={setView} motifIntensity={t.motif} />;
      case "course":
        return <CourseDetailScreen courseId={view.id} onNavigate={setView} motifIntensity={t.motif} />;
      case "lesson":
        return <LessonScreen courseId={view.courseId} lessonIndex={view.lessonIndex} onNavigate={setView} />;
      case "about":
        return <AboutScreen motifIntensity={t.motif} />;
      case "library":
        return <LibraryScreen onNavigate={setView} />;
      case "profile":
        return <ProfileScreen2 onNavigate={setView} onSignOut={() => { setIsAuthed(false); setView({ name: "home" }); }} />;
      case "signin":
        return <SignInScreen onNavigate={setView} onSignIn={() => setIsAuthed(true)} />;
      case "register":
        return <RegisterScreen onNavigate={setView} onSignIn={() => setIsAuthed(true)} />;
      case "forgot":
        return <ForgotPasswordScreen onNavigate={setView} />;
      case "myCourses":
        return <MyCoursesScreen onNavigate={setView} />;
      case "createCourse":
        return <CreateCourseScreen onNavigate={setView} />;
      case "users":
        return <UsersScreen />;
      case "paymentSuccess":
        return <PaymentSuccessScreen onNavigate={setView} courseId={view.courseId || 3} />;
      case "paymentCancel":
        return <PaymentCancelScreen onNavigate={setView} courseId={view.courseId || 3} />;
      default:
        return <HomeScreen onNavigate={setView} motifIntensity={t.motif} />;
    }
  };

  return (
    <React.Fragment>
      <Nav
        current={view}
        onNavigate={setView}
        isAuthed={isAuthed}
        onToggleAuth={() => setIsAuthed((v) => !v)}
        dark={!!t.dark}
        onToggleDark={() => setTweak("dark", !t.dark)}
      />
      <main>
        {renderView()}
      </main>

      {/* Quiet footer */}
      <footer style={{
        borderTop: "1px solid var(--hair)",
        padding: "48px 40px",
        marginTop: 80,
      }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 24, flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <BrandLeaf size={13} />
            <span className="serif" style={{ fontSize: 16, color: "var(--ink)" }}>mindleaf</span>
            <span className="mono" style={{ fontSize: 11, color: "var(--ink-faint)", letterSpacing: "0.14em", marginLeft: 14 }}>est. 2024</span>
          </div>
          <div style={{ display: "flex", gap: 28, fontSize: 13, color: "var(--ink-soft)" }}>
            <button>catalogue</button>
            <button>teach a course</button>
            <button>contact</button>
            <button>terms</button>
          </div>
        </div>
      </footer>

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakToggle label="Dark mode" value={!!t.dark} onChange={(v) => setTweak("dark", v)} />
        <TweakRadio
          label="Accent"
          value={t.accent}
          options={["moss", "forest", "sage", "olive"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["cozy", "regular", "airy"]}
          onChange={(v) => setTweak("density", v)}
        />
        <TweakRadio
          label="Leaf motifs"
          value={t.motif}
          options={["off", "subtle", "lush"]}
          onChange={(v) => setTweak("motif", v)}
        />
        <TweakSection label="Public" />
        <TweakButton label="Home"            onClick={() => setView({ name: "home" })} />
        <TweakButton label="Courses"         onClick={() => setView({ name: "courses" })} />
        <TweakButton label="Course detail"   onClick={() => setView({ name: "course", id: 1 })} />
        <TweakButton label="Lesson view"     onClick={() => setView({ name: "lesson", courseId: 1, lessonIndex: 3 })} />
        <TweakButton label="About"           onClick={() => setView({ name: "about" })} />
        <TweakSection label="Account" />
        <TweakButton label="Sign in"         onClick={() => setView({ name: "signin" })} />
        <TweakButton label="Register"        onClick={() => setView({ name: "register" })} />
        <TweakButton label="Forgot password" onClick={() => setView({ name: "forgot" })} />
        <TweakButton label="Profile"         onClick={() => setView({ name: "profile" })} />
        <TweakButton label="Library"         onClick={() => setView({ name: "library" })} />
        <TweakSection label="Studio" />
        <TweakButton label="My courses"      onClick={() => setView({ name: "myCourses" })} />
        <TweakButton label="Create a course" onClick={() => setView({ name: "createCourse" })} />
        <TweakButton label="Users (admin)"   onClick={() => setView({ name: "users" })} />
        <TweakSection label="Payment" />
        <TweakButton label="Payment success" onClick={() => setView({ name: "paymentSuccess", courseId: 3 })} />
        <TweakButton label="Payment cancel"  onClick={() => setView({ name: "paymentCancel", courseId: 3 })} />
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
