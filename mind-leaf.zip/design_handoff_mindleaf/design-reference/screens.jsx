// screens.jsx — top-level screens for mindleaf.
// Uses globals from data.jsx and components.jsx.

const PAGE_MAX = 1180;

// ---------------------------------------------------------------
// Home — a quiet entry, with the brand statement and a small
// list of "currently tending" courses + featured.
// ---------------------------------------------------------------
function HomeScreen({ onNavigate, motifIntensity }) {
  const featured = COURSES[0];
  const tending = COURSES.filter((c) => c.completed > 0 && c.completed < c.lessons);
  return (
    <div className="screen">
      {/* Hero — almost all whitespace */}
      <section style={{ position: "relative", padding: "120px 40px 80px", maxWidth: PAGE_MAX, margin: "0 auto" }}>
        <LeafScatter count={8} intensity={motifIntensity} />
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 28 }}>
          mindleaf · est. 2024
        </div>
        <h1 className="serif" style={{
          margin: 0, fontSize: "clamp(48px, 7vw, 96px)",
          lineHeight: 1.02, letterSpacing: "-0.02em",
          color: "var(--ink)", maxWidth: 900,
          fontWeight: 500,
        }}>
          A quieter place<br />to learn one thing<br />at a time.
        </h1>
        <p style={{ marginTop: 36, maxWidth: 520, color: "var(--ink-soft)", fontSize: 17, lineHeight: 1.6 }}>
          Short, slow courses for people who would rather attend to one thing properly than skim ten. Made by teachers, writers, and craftspeople in a hurry to be unhurried.
        </p>
        <div style={{ marginTop: 44, display: "flex", alignItems: "center", gap: 24 }}>
          <button
            onClick={() => onNavigate({ name: "courses" })}
            style={{
              background: "var(--ink)", color: "var(--paper)",
              padding: "16px 28px", borderRadius: 4,
              fontSize: 14, letterSpacing: "0.04em",
              display: "inline-flex", alignItems: "center", gap: 10,
            }}
          >
            browse the catalogue
            <span style={{ display: "inline-flex", color: "var(--moss-soft)" }}>
              <Leaf size={14} strokeWidth={0} tilt={-20} />
            </span>
          </button>
          <button
            onClick={() => onNavigate({ name: "about" })}
            style={{
              padding: "16px 4px", color: "var(--ink-soft)", fontSize: 14,
              borderBottom: "1px solid var(--hair-strong)",
            }}
          >
            our practice ↓
          </button>
        </div>

        {/* Single large leaf as a quiet anchor */}
        <div aria-hidden="true" style={{
          position: "absolute", right: 40, top: 80, opacity: 0.10,
          color: "var(--moss)",
        }}>
          <Leaf size={360} strokeWidth={0} tilt={-8} />
        </div>
      </section>

      {/* Three principles — single line each, lots of room */}
      <section style={{ borderTop: "1px solid var(--hair)", borderBottom: "1px solid var(--hair)", padding: "72px 40px", background: "color-mix(in oklab, var(--paper-2) 60%, transparent)" }}>
        <div style={{ maxWidth: PAGE_MAX, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 56 }}>
          {[
            ["i.",   "Slow on purpose",      "Lessons are paced for the depth they ask for, not the speed you'd prefer."],
            ["ii.",  "One thing at a time",  "Each course is a single, finishable subject. No bundles, no upsells."],
            ["iii.", "Quiet by design",      "No streaks, no notifications, no leaderboards. You return because you want to."],
          ].map(([num, title, body]) => (
            <div key={num}>
              <div className="serif" style={{ fontSize: 22, color: "var(--moss)", marginBottom: 16 }}>{num}</div>
              <h3 className="serif" style={{ margin: 0, marginBottom: 12, fontSize: 22, color: "var(--ink)", lineHeight: 1.2 }}>{title}</h3>
              <p style={{ margin: 0, fontSize: 14.5, color: "var(--ink-soft)", lineHeight: 1.65 }}>{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Tending — courses in progress (only if any) */}
      {tending.length > 0 && (
        <section style={{ padding: "96px 40px 32px", maxWidth: PAGE_MAX, margin: "0 auto" }}>
          <SectionHeading kicker="continuing">Currently tending</SectionHeading>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "var(--row-gap, 28px)" }}>
            {tending.map((c) => (
              <TendingCard key={c.id} course={c} onOpen={(id) => onNavigate({ name: "course", id })} />
            ))}
          </div>
        </section>
      )}

      {/* Featured course — single large card */}
      <section style={{ padding: "72px 40px 120px", maxWidth: PAGE_MAX, margin: "0 auto" }}>
        <SectionHeading kicker="featured this season">A course we recommend</SectionHeading>
        <div
          onClick={() => onNavigate({ name: "course", id: featured.id })}
          style={{
            display: "grid", gridTemplateColumns: "1.2fr 1fr",
            gap: 0,
            border: "1px solid var(--hair)",
            borderRadius: "var(--radius)",
            overflow: "hidden", cursor: "pointer",
            background: "var(--paper-2)",
          }}
        >
          {/* image placeholder */}
          <div style={{
            position: "relative",
            background: `repeating-linear-gradient(135deg, var(--moss-wash) 0 2px, transparent 2px 14px), var(--paper)`,
            minHeight: 360,
            borderRight: "1px solid var(--hair)",
            display: "grid", placeItems: "center",
          }}>
            <div style={{ color: "var(--moss)", opacity: 0.5 }}>
              <Leaf size={140} strokeWidth={0} tilt={-12} />
            </div>
            <div className="mono" style={{ position: "absolute", bottom: 18, left: 22, fontSize: 11, letterSpacing: "0.12em", color: "var(--ink-faint)" }}>
              [ cover · author portrait ]
            </div>
          </div>
          <div style={{ padding: 44, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div>
              <div className="mono" style={{ fontSize: 11, letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--ink-faint)", marginBottom: 18 }}>
                {featured.season} · {featured.lessons} lessons · {featured.minutes} min each
              </div>
              <h3 className="serif" style={{ margin: 0, fontSize: 40, lineHeight: 1.08, color: "var(--ink)", marginBottom: 16 }}>
                {featured.title}
              </h3>
              <p style={{ margin: 0, fontSize: 16, color: "var(--ink-soft)", lineHeight: 1.6, maxWidth: 420 }}>
                {featured.description}
              </p>
            </div>
            <div style={{ marginTop: 36, paddingTop: 24, borderTop: "1px solid var(--hair)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <div style={{ fontSize: 13, color: "var(--ink)" }}>{featured.author}</div>
                <div style={{ fontSize: 12, color: "var(--ink-faint)" }}>{featured.authorRole}</div>
              </div>
              <span className="serif" style={{ fontSize: 22, color: "var(--ink)" }}>free</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

// "Tending" card variant — horizontal, with the leaf progress row
function TendingCard({ course, onOpen }) {
  return (
    <article
      onClick={() => onOpen(course.id)}
      style={{
        padding: 24,
        border: "1px solid var(--hair)",
        background: "var(--paper)",
        borderRadius: "var(--radius)",
        cursor: "pointer",
        transition: "border-color 220ms ease",
      }}
      onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--hair-strong)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--hair)"; }}
    >
      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", color: "var(--moss)", marginBottom: 8 }}>
        in progress
      </div>
      <h4 className="serif" style={{ margin: 0, marginBottom: 18, fontSize: 22, lineHeight: 1.15, color: "var(--ink)" }}>
        {course.title}
      </h4>
      <LeafRow total={course.lessons} completed={course.completed} size={14} gap={6} />
      <div style={{ marginTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <ProgressLabel completed={course.completed} total={course.lessons} />
        <span style={{ fontSize: 12, color: "var(--ink-soft)" }}>continue →</span>
      </div>
    </article>
  );
}

// ---------------------------------------------------------------
// Courses — the catalogue, with filters and a calm grid.
// ---------------------------------------------------------------
function CoursesScreen({ onNavigate, motifIntensity }) {
  const [filter, setFilter] = React.useState("all");
  const filters = [
    { key: "all", label: "all courses", count: COURSES.length },
    { key: "free", label: "free", count: COURSES.filter((c) => c.price == null).length },
    { key: "paid", label: "studio", count: COURSES.filter((c) => c.price != null).length },
    { key: "tending", label: "in progress", count: COURSES.filter((c) => c.completed > 0 && c.completed < c.lessons).length },
  ];
  const filtered = COURSES.filter((c) => {
    if (filter === "free") return c.price == null;
    if (filter === "paid") return c.price != null;
    if (filter === "tending") return c.completed > 0 && c.completed < c.lessons;
    return true;
  });

  return (
    <div className="screen" style={{ position: "relative" }}>
      <LeafScatter count={6} intensity={motifIntensity} />
      <section style={{ padding: "96px 40px 32px", maxWidth: PAGE_MAX, margin: "0 auto" }}>
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 22 }}>
          catalogue · spring 2026
        </div>
        <h1 className="serif" style={{ margin: 0, fontSize: 64, lineHeight: 1.05, color: "var(--ink)", letterSpacing: "-0.015em", maxWidth: 720 }}>
          Six courses, attended to slowly.
        </h1>
        <p style={{ marginTop: 18, maxWidth: 520, fontSize: 16, color: "var(--ink-soft)", lineHeight: 1.6 }}>
          A small catalogue, deliberately. Each course is a single subject taught by one teacher, in lessons of fifteen minutes or less.
        </p>
      </section>

      {/* Filters — minimal, single-line */}
      <section style={{ padding: "32px 40px 12px", maxWidth: PAGE_MAX, margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 0, borderTop: "1px solid var(--hair)", borderBottom: "1px solid var(--hair)", padding: "16px 0" }}>
          {filters.map((f, i) => {
            const active = filter === f.key;
            return (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                style={{
                  display: "flex", alignItems: "baseline", gap: 8,
                  padding: "8px 22px 8px 0",
                  marginRight: i < filters.length - 1 ? 22 : 0,
                  borderRight: i < filters.length - 1 ? "1px solid var(--hair)" : "none",
                  fontSize: 14,
                  color: active ? "var(--ink)" : "var(--ink-soft)",
                  letterSpacing: "0.01em",
                  position: "relative",
                }}
              >
                {active && (
                  <span style={{ color: "var(--moss)", display: "inline-flex" }}>
                    <Leaf size={10} strokeWidth={0} tilt={-20} />
                  </span>
                )}
                <span>{f.label}</span>
                <span className="mono" style={{ fontSize: 11, color: "var(--ink-faint)" }}>{String(f.count).padStart(2, "0")}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section style={{ padding: "32px 40px 120px", maxWidth: PAGE_MAX, margin: "0 auto" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "var(--row-gap, 28px)" }}>
          {filtered.map((c) => (
            <CourseCard key={c.id} course={c} onOpen={(id) => onNavigate({ name: "course", id })} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div style={{ textAlign: "center", padding: "80px 0", color: "var(--ink-faint)" }}>
            <Leaf size={40} strokeWidth={1} />
            <p style={{ marginTop: 16, fontSize: 14 }}>Nothing here yet. Try another filter.</p>
          </div>
        )}
      </section>
    </div>
  );
}

// ---------------------------------------------------------------
// CourseDetail — title, growing-stem progress, lesson list.
// ---------------------------------------------------------------
function CourseDetailScreen({ courseId, onNavigate, motifIntensity }) {
  const course = COURSES.find((c) => c.id === courseId);
  const baseLessons = lessonsFor(courseId);
  const [lessons, setLessons] = React.useState(baseLessons);
  const [currentIndex, setCurrentIndex] = React.useState(
    Math.min(baseLessons.findIndex((l) => !l.done), baseLessons.length - 1)
  );
  React.useEffect(() => {
    setLessons(baseLessons);
    setCurrentIndex(Math.min(baseLessons.findIndex((l) => !l.done), baseLessons.length - 1));
  }, [courseId]);

  if (!course) return null;
  const completed = lessons.filter((l) => l.done).length;
  const isPaid = course.price != null;
  const isEnrolled = completed > 0 || !isPaid; // mock

  const toggleLesson = (idx) => {
    setLessons((prev) => prev.map((l, i) => i === idx ? { ...l, done: !l.done } : l));
  };

  return (
    <div className="screen" style={{ maxWidth: PAGE_MAX, margin: "0 auto", padding: "48px 40px 120px" }}>
      <button
        onClick={() => onNavigate({ name: "courses" })}
        style={{ display: "inline-flex", alignItems: "center", gap: 8, color: "var(--ink-soft)", fontSize: 13, marginBottom: 36 }}
      >
        ← back to catalogue
      </button>

      <header style={{ borderBottom: "1px solid var(--hair)", paddingBottom: 48, marginBottom: 56, display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 64, alignItems: "end" }}>
        <div>
          <div className="mono" style={{ fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 22 }}>
            {course.season} · {course.lessons} lessons · {course.minutes}-min average
          </div>
          <h1 className="serif" style={{ margin: 0, fontSize: "clamp(48px, 6vw, 76px)", lineHeight: 1.04, letterSpacing: "-0.018em", color: "var(--ink)", maxWidth: 700 }}>
            {course.title}
          </h1>
          <p style={{ marginTop: 24, fontSize: 17, color: "var(--ink-soft)", lineHeight: 1.6, maxWidth: 580 }}>
            {course.description}
          </p>
        </div>
        <aside style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 28 }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 13, color: "var(--ink)", marginBottom: 4 }}>{course.author}</div>
            <div style={{ fontSize: 12, color: "var(--ink-faint)" }}>{course.authorRole}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", color: "var(--ink-faint)", marginBottom: 6 }}>tuition</div>
            <div className="serif" style={{ fontSize: 36, color: "var(--ink)", lineHeight: 1 }}>
              {isPaid ? `¥${(course.price / 100).toFixed(0)}` : "free"}
            </div>
          </div>
          {!isEnrolled ? (
            <button style={{
              background: "var(--ink)", color: "var(--paper)",
              padding: "14px 26px", borderRadius: 4,
              fontSize: 14, letterSpacing: "0.04em",
              display: "inline-flex", alignItems: "center", gap: 8,
            }}>
              {isPaid ? "purchase course" : "begin course"}
              <Leaf size={12} strokeWidth={0} tilt={-20} color="var(--moss-soft)" />
            </button>
          ) : (
            <div style={{ display: "flex", alignItems: "center", gap: 10, color: "var(--moss-deep)", fontSize: 13 }}>
              <Leaf size={12} strokeWidth={0} /> tending — {completed} of {lessons.length} complete
            </div>
          )}
        </aside>
      </header>

      {/* Body: stem on the left, lessons on the right */}
      <div style={{ display: "grid", gridTemplateColumns: "140px 1fr", gap: 56, alignItems: "flex-start" }}>
        {/* Sticky stem */}
        <div style={{ position: "sticky", top: 100 }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--ink-faint)", marginBottom: 18, textAlign: "center" }}>
            growth
          </div>
          <GrowingStem
            lessons={lessons}
            currentIndex={currentIndex}
            onJump={(i) => setCurrentIndex(i)}
          />
          <div style={{ marginTop: 16, textAlign: "center" }}>
            <ProgressLabel completed={completed} total={lessons.length} />
          </div>
        </div>

        {/* Lesson list */}
        <div>
          <SectionHeading kicker="curriculum">Lessons</SectionHeading>
          <ol style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {lessons.map((lesson, i) => {
              const isCurrent = i === currentIndex;
              return (
                <li
                  key={lesson.id}
                  style={{
                    borderTop: i === 0 ? "1px solid var(--hair)" : "none",
                    borderBottom: "1px solid var(--hair)",
                  }}
                >
                  <div
                    onClick={() => setCurrentIndex(i)}
                    style={{
                      padding: "28px 0",
                      display: "grid",
                      gridTemplateColumns: "44px 1fr auto",
                      gap: 24,
                      alignItems: "start",
                      cursor: "pointer",
                      background: isCurrent ? "color-mix(in oklab, var(--moss-wash) 60%, transparent)" : "transparent",
                      marginLeft: isCurrent ? -16 : 0,
                      paddingLeft: isCurrent ? 16 : 0,
                      paddingRight: isCurrent ? 16 : 0,
                      marginRight: isCurrent ? -16 : 0,
                      transition: "background 220ms ease, margin 220ms ease, padding 220ms ease",
                      borderRadius: isCurrent ? 4 : 0,
                    }}
                  >
                    <span className="mono" style={{ fontSize: 12, color: lesson.done ? "var(--moss)" : "var(--ink-faint)", letterSpacing: "0.1em", paddingTop: 4 }}>
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div>
                      <h4 className="serif" style={{ margin: 0, fontSize: 22, color: "var(--ink)", lineHeight: 1.2, marginBottom: 6 }}>
                        {lesson.title}
                      </h4>
                      <p style={{ margin: 0, fontSize: 14, color: "var(--ink-soft)", lineHeight: 1.55, maxWidth: 620 }}>
                        {lesson.excerpt}
                      </p>
                      <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 18 }}>
                        <span className="mono" style={{ fontSize: 11, color: "var(--ink-faint)", letterSpacing: "0.08em" }}>
                          {lesson.minutes} min · video + pdf
                        </span>
                        <button
                          onClick={(e) => { e.stopPropagation(); toggleLesson(i); }}
                          style={{ fontSize: 11, color: "var(--moss-deep)", display: "inline-flex", alignItems: "center", gap: 6 }}
                        >
                          <Leaf size={11} strokeWidth={lesson.done ? 0 : 1.2} filled={lesson.done} />
                          {lesson.done ? "completed" : "mark complete"}
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); onNavigate({ name: "lesson", courseId: course.id, lessonIndex: i }); }}
                          style={{ fontSize: 11, color: "var(--ink-soft)" }}
                        >
                          open →
                        </button>
                      </div>
                    </div>
                    <span style={{ color: lesson.done ? "var(--moss)" : (isCurrent ? "var(--moss-deep)" : "var(--ink-faint)"), opacity: lesson.done || isCurrent ? 1 : 0.5 }}>
                      <Leaf size={22} filled={lesson.done || isCurrent} strokeWidth={lesson.done || isCurrent ? 0 : 1.2} tilt={-22 + ((i * 7) % 14)} />
                    </span>
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------
// LessonView — focused, reading-room aesthetic.
// ---------------------------------------------------------------
function LessonScreen({ courseId, lessonIndex, onNavigate }) {
  const course = COURSES.find((c) => c.id === courseId);
  const lessons = lessonsFor(courseId);
  const [idx, setIdx] = React.useState(lessonIndex || 0);
  const [done, setDone] = React.useState(() => lessons.map((l) => l.done));
  React.useEffect(() => { setIdx(lessonIndex || 0); }, [lessonIndex, courseId]);

  if (!course) return null;
  const lesson = lessons[idx];
  const completed = done.filter(Boolean).length;

  const toggle = (i) => setDone((prev) => prev.map((v, j) => j === i ? !v : v));

  return (
    <div className="screen" style={{ maxWidth: 1080, margin: "0 auto", padding: "40px 40px 120px" }}>
      <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 36 }}>
        <button
          onClick={() => onNavigate({ name: "course", id: courseId })}
          style={{ display: "inline-flex", alignItems: "center", gap: 8, color: "var(--ink-soft)", fontSize: 13 }}
        >
          ← {course.title}
        </button>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <LeafRow total={lessons.length} completed={completed} size={14} gap={5} onLeafClick={(i) => setIdx(i)} />
        </div>
      </header>

      {/* Video panel */}
      <div style={{
        background: "var(--paper-2)",
        border: "1px solid var(--hair)",
        borderRadius: "var(--radius)",
        aspectRatio: "16 / 9",
        display: "grid", placeItems: "center",
        position: "relative", overflow: "hidden",
        marginBottom: 40,
        backgroundImage: `repeating-linear-gradient(135deg, var(--moss-wash) 0 2px, transparent 2px 16px)`,
      }}>
        <button style={{
          width: 72, height: 72, borderRadius: "50%",
          background: "var(--paper)",
          border: "1px solid var(--hair-strong)",
          display: "grid", placeItems: "center",
        }}>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="var(--ink)"><path d="M5 3 L17 10 L5 17 Z" /></svg>
        </button>
        <div className="mono" style={{ position: "absolute", bottom: 16, left: 22, fontSize: 11, letterSpacing: "0.12em", color: "var(--ink-faint)" }}>
          [ lesson video · {lesson.minutes}:00 ]
        </div>
        <div className="mono" style={{ position: "absolute", bottom: 16, right: 22, fontSize: 11, letterSpacing: "0.12em", color: "var(--ink-faint)" }}>
          mindleaf player
        </div>
      </div>

      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 18 }}>
        Lesson {String(idx + 1).padStart(2, "0")} · {lesson.minutes} min
      </div>
      <h1 className="serif" style={{ margin: 0, fontSize: 52, lineHeight: 1.05, letterSpacing: "-0.015em", color: "var(--ink)", marginBottom: 24, maxWidth: 800 }}>
        {lesson.title}
      </h1>
      <p style={{ fontSize: 18, lineHeight: 1.7, color: "var(--ink-soft)", maxWidth: 680, margin: 0 }}>
        {lesson.excerpt}
      </p>
      <p style={{ fontSize: 16, lineHeight: 1.75, color: "var(--ink-soft)", maxWidth: 680, marginTop: 22 }}>
        Continue the practice this week by carrying the lesson with you. Read it twice in the morning; once again before sleep. Notice what becomes familiar, and what stays strange.
      </p>

      {/* Lesson footer — mark complete + nav */}
      <div style={{ marginTop: 56, paddingTop: 32, borderTop: "1px solid var(--hair)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24, flexWrap: "wrap" }}>
        <button
          onClick={() => toggle(idx)}
          style={{
            display: "inline-flex", alignItems: "center", gap: 12,
            background: done[idx] ? "var(--moss-wash)" : "var(--ink)",
            color: done[idx] ? "var(--moss-deep)" : "var(--paper)",
            padding: "14px 22px", borderRadius: 4,
            fontSize: 14, letterSpacing: "0.03em",
            border: done[idx] ? "1px solid var(--moss-soft)" : "1px solid var(--ink)",
          }}
        >
          <Leaf size={14} strokeWidth={done[idx] ? 0 : 1.2} filled={done[idx]} color={done[idx] ? "var(--moss)" : "var(--moss-soft)"} />
          {done[idx] ? "lesson complete" : "mark this lesson complete"}
        </button>

        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <button
            disabled={idx === 0}
            onClick={() => setIdx((i) => Math.max(0, i - 1))}
            style={{ fontSize: 13, color: idx === 0 ? "var(--ink-faint)" : "var(--ink-soft)", padding: "10px 12px" }}
          >
            ← previous
          </button>
          <button
            disabled={idx === lessons.length - 1}
            onClick={() => setIdx((i) => Math.min(lessons.length - 1, i + 1))}
            style={{
              fontSize: 13, color: idx === lessons.length - 1 ? "var(--ink-faint)" : "var(--ink)", padding: "10px 14px",
              borderBottom: "1px solid var(--hair-strong)",
              display: "inline-flex", alignItems: "center", gap: 8,
            }}
          >
            next lesson →
          </button>
        </div>
      </div>

      {/* Lesson contents (PDF placeholder) */}
      <div style={{
        marginTop: 56,
        padding: "32px",
        border: "1px solid var(--hair)",
        borderRadius: "var(--radius)",
        background: "var(--paper-2)",
        display: "flex", alignItems: "center", gap: 24,
      }}>
        <span style={{ color: "var(--moss)" }}><Leaf size={28} strokeWidth={0} /></span>
        <div style={{ flex: 1 }}>
          <div className="serif" style={{ fontSize: 18, color: "var(--ink)" }}>Lesson notes (pdf)</div>
          <div style={{ fontSize: 13, color: "var(--ink-soft)", marginTop: 2 }}>A short companion to read before or after the video — 3 pages.</div>
        </div>
        <button style={{ fontSize: 13, color: "var(--ink-soft)", padding: "10px 16px", border: "1px solid var(--hair-strong)", borderRadius: 4 }}>
          open pdf →
        </button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------
// About screen — short, anchors the brand statement.
// ---------------------------------------------------------------
function AboutScreen({ motifIntensity }) {
  return (
    <div className="screen" style={{ maxWidth: 880, margin: "0 auto", padding: "120px 40px", position: "relative" }}>
      <LeafScatter count={5} intensity={motifIntensity} />
      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 28 }}>
        about
      </div>
      <h1 className="serif" style={{ margin: 0, fontSize: 64, lineHeight: 1.05, letterSpacing: "-0.018em", color: "var(--ink)", marginBottom: 36 }}>
        Our practice
      </h1>
      <p style={{ fontSize: 19, lineHeight: 1.7, color: "var(--ink-soft)", marginBottom: 28 }}>
        Mindleaf is a small studio of teachers, writers, and craftspeople. We make courses that take more time than they need to, and we recommend that you take even longer with them.
      </p>
      <p style={{ fontSize: 17, lineHeight: 1.75, color: "var(--ink-soft)", marginBottom: 28 }}>
        There are no streaks, no badges, no recommendation engine. There is a leaf for each lesson, and when you complete one, it fills in. When you finish a course, a small plant has grown beside it. That is the entire system.
      </p>
      <p style={{ fontSize: 17, lineHeight: 1.75, color: "var(--ink-soft)" }}>
        We release four to six courses each season. If you would like to teach one, please write to us.
      </p>
      <div style={{ marginTop: 56, paddingTop: 32, borderTop: "1px solid var(--hair)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div className="serif" style={{ fontSize: 22, color: "var(--ink)" }}>hello@mindleaf.studio</div>
        <div style={{ color: "var(--moss)" }}><Leaf size={32} strokeWidth={0} tilt={-12} /></div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------
// Library — placeholder for the authenticated 'your library' view.
// ---------------------------------------------------------------
function LibraryScreen({ onNavigate }) {
  const tending = COURSES.filter((c) => c.completed > 0);
  return (
    <div className="screen" style={{ maxWidth: PAGE_MAX, margin: "0 auto", padding: "96px 40px 120px" }}>
      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 22 }}>
        your library
      </div>
      <h1 className="serif" style={{ margin: 0, fontSize: 64, lineHeight: 1.05, letterSpacing: "-0.015em", color: "var(--ink)", maxWidth: 720, marginBottom: 12 }}>
        What you're tending.
      </h1>
      <p style={{ fontSize: 16, color: "var(--ink-soft)", maxWidth: 520, lineHeight: 1.6, marginBottom: 56 }}>
        Courses you've started, and the plants growing alongside them.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(360px, 1fr))", gap: 32 }}>
        {tending.map((c) => (
          <article
            key={c.id}
            onClick={() => onNavigate({ name: "course", id: c.id })}
            style={{
              padding: 32,
              border: "1px solid var(--hair)",
              background: "var(--paper-2)",
              borderRadius: "var(--radius)",
              cursor: "pointer",
              display: "grid", gridTemplateColumns: "1fr auto", gap: 24, alignItems: "start",
            }}
          >
            <div>
              <h4 className="serif" style={{ margin: 0, fontSize: 24, lineHeight: 1.15, color: "var(--ink)", marginBottom: 8 }}>{c.title}</h4>
              <div style={{ fontSize: 13, color: "var(--ink-faint)", marginBottom: 18 }}>{c.author}</div>
              <LeafRow total={c.lessons} completed={c.completed} size={13} gap={5} />
              <div style={{ marginTop: 12 }}>
                <ProgressLabel completed={c.completed} total={c.lessons} />
              </div>
            </div>
            <div style={{ width: 80, height: 100, position: "relative" }}>
              <MiniStem completed={c.completed} total={c.lessons} />
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function MiniStem({ completed, total }) {
  const h = 100;
  const start = 6;
  const stemX = 40;
  const step = (h - 18) / Math.max(total - 1, 1);
  const tipY = start + step * Math.max(0, completed - 1);
  return (
    <svg viewBox="0 0 80 100" width="80" height="100" style={{ overflow: "visible" }}>
      <line x1={stemX} y1={start} x2={stemX} y2={h - 4} stroke="var(--hair-strong)" strokeWidth="1" />
      <line x1={stemX} y1={start} x2={stemX} y2={tipY + 8} stroke="var(--moss)" strokeWidth="1.6" strokeLinecap="round" />
      {completed > 0 && <circle cx={stemX} cy={tipY + 8} r="1.8" fill="var(--moss)" />}
      {Array.from({ length: total }).map((_, i) => {
        const y = start + step * i;
        const side = i % 2 === 0 ? -1 : 1;
        const done = i < completed;
        const petEndX = stemX + side * 14;
        const petEndY = y - 3;
        const color = done ? "var(--moss)" : "var(--ink-faint)";
        return (
          <g key={i}>
            <path d={`M ${stemX} ${y} Q ${stemX + side * 5} ${y + 1} ${petEndX} ${petEndY}`}
                  stroke={color} strokeWidth={done ? 1.1 : 0.8} fill="none" strokeLinecap="round"
                  opacity={done ? 1 : 0.55} />
            <g transform={`translate(${petEndX} ${petEndY}) rotate(${side * 65})`}>
              <path d="M0 0 C -3.5 -1.5, -5 -6, 0 -10 C 5 -6, 3.5 -1.5, 0 0 Z"
                    fill={done ? color : "transparent"}
                    stroke={color}
                    strokeWidth={done ? 0 : 0.9} opacity={done ? 1 : 0.7} />
            </g>
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------
// Profile / sign-in stub
// ---------------------------------------------------------------
function ProfileScreen() {
  return (
    <div className="screen" style={{ maxWidth: 720, margin: "0 auto", padding: "120px 40px" }}>
      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 24 }}>
        account
      </div>
      <h1 className="serif" style={{ margin: 0, fontSize: 56, lineHeight: 1.05, color: "var(--ink)", marginBottom: 32 }}>
        mira holt
      </h1>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 56 }}>
        <Stat label="courses tending" value="3" />
        <Stat label="lessons complete" value="21" />
        <Stat label="reading minutes (season)" value="412" />
        <Stat label="member since" value="spring '24" />
      </div>
      <button style={{ fontSize: 13, color: "var(--ink-soft)", padding: "12px 18px", border: "1px solid var(--hair-strong)", borderRadius: 4 }}>
        sign out
      </button>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div style={{ borderTop: "1px solid var(--hair)", paddingTop: 20 }}>
      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", color: "var(--ink-faint)", textTransform: "uppercase", marginBottom: 10 }}>
        {label}
      </div>
      <div className="serif" style={{ fontSize: 32, color: "var(--ink)", lineHeight: 1.1 }}>{value}</div>
    </div>
  );
}

Object.assign(window, { HomeScreen, CoursesScreen, CourseDetailScreen, LessonScreen, AboutScreen, LibraryScreen, ProfileScreen });
