// screens-auth.jsx — auth, profile, creator/admin dashboards, payment.
// Uses globals from data.jsx and components.jsx.

const AUTH_MAX = 1180;

// ---------------------------------------------------------------
// Shared auth shell: a centered card on the left, a quiet leaf
// composition on the right.
// ---------------------------------------------------------------
function AuthShell({ kicker, title, intro, children, side, onNavigate }) {
  return (
    <div className="screen" style={{ minHeight: "calc(100vh - 84px)", display: "grid", gridTemplateColumns: "minmax(0,1fr) minmax(0,1fr)", maxWidth: AUTH_MAX, margin: "0 auto" }}>
      <section style={{ padding: "96px 56px 64px", display: "flex", flexDirection: "column", justifyContent: "center", maxWidth: 520 }}>
        <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 20 }}>
          {kicker}
        </div>
        <h1 className="serif" style={{ margin: 0, fontSize: 56, lineHeight: 1.05, letterSpacing: "-0.018em", color: "var(--ink)", marginBottom: 16 }}>
          {title}
        </h1>
        {intro && (
          <p style={{ margin: 0, marginBottom: 44, fontSize: 16, lineHeight: 1.6, color: "var(--ink-soft)" }}>
            {intro}
          </p>
        )}
        {children}
      </section>
      <aside style={{ position: "relative", background: "var(--paper-2)", borderLeft: "1px solid var(--hair)", overflow: "hidden" }}>
        {side}
      </aside>
    </div>
  );
}

// A decorative "growing plant" panel — bigger version of GrowingStem
// used as the visual right-hand side of auth pages.
function AuthLeafComposition({ progress = 4 }) {
  const lessons = Array.from({ length: 7 }).map((_, i) => ({
    id: i, title: `Lesson ${i + 1}`, done: i < progress,
  }));
  return (
    <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24 }}>
        <GrowingStem lessons={lessons} currentIndex={progress} onJump={() => {}} />
        <div style={{ textAlign: "center", maxWidth: 280 }}>
          <div className="serif" style={{ fontSize: 22, color: "var(--ink)", marginBottom: 6 }}>
            One leaf at a time.
          </div>
          <p style={{ margin: 0, fontSize: 13, color: "var(--ink-soft)", lineHeight: 1.55 }}>
            Each lesson you finish unfurls a leaf alongside the course.
          </p>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------
// Sign-in
// ---------------------------------------------------------------
function SignInScreen({ onNavigate, onSignIn }) {
  const [email, setEmail] = React.useState("mira@mindleaf.studio");
  const [pw, setPw] = React.useState("");
  return (
    <AuthShell
      kicker="welcome back"
      title="Sign in"
      intro="Pick up where you left off. Your leaves are waiting where you last set them."
      side={<AuthLeafComposition progress={5} />}
      onNavigate={onNavigate}
    >
      <form onSubmit={(e) => { e.preventDefault(); onSignIn && onSignIn(); onNavigate({ name: "library" }); }}>
        <Field label="Email" required>
          <TextInput value={email} onChange={setEmail} type="email" autoComplete="email" placeholder="you@example.com" />
        </Field>
        <Field label="Password" hint={<button type="button" onClick={() => onNavigate({ name: "forgot" })} style={{ color: "var(--moss)", fontSize: 11 }}>forgot</button>} required>
          <TextInput value={pw} onChange={setPw} type="password" autoComplete="current-password" placeholder="••••••••" />
        </Field>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 32, gap: 16, flexWrap: "wrap" }}>
          <PrimaryButton onClick={() => { onSignIn && onSignIn(); onNavigate({ name: "library" }); }}>
            sign in
            <Leaf size={12} strokeWidth={0} tilt={-20} color="var(--moss-soft)" />
          </PrimaryButton>
          <button type="button" onClick={() => onNavigate({ name: "register" })} style={{ fontSize: 13, color: "var(--ink-soft)" }}>
            new here? create an account →
          </button>
        </div>
      </form>
    </AuthShell>
  );
}

// ---------------------------------------------------------------
// Register
// ---------------------------------------------------------------
function RegisterScreen({ onNavigate, onSignIn }) {
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [pw, setPw] = React.useState("");
  const [role, setRole] = React.useState("learner");
  return (
    <AuthShell
      kicker="begin"
      title="Create a quiet account"
      intro="No newsletters, no streaks. Just the courses, the leaves, and the time you give them."
      side={<AuthLeafComposition progress={2} />}
      onNavigate={onNavigate}
    >
      <form onSubmit={(e) => { e.preventDefault(); onSignIn && onSignIn(); onNavigate({ name: "library" }); }}>
        <Field label="Name" required>
          <TextInput value={name} onChange={setName} placeholder="what to call you" autoComplete="name" />
        </Field>
        <Field label="Email" required>
          <TextInput value={email} onChange={setEmail} type="email" placeholder="you@example.com" autoComplete="email" />
        </Field>
        <Field label="Password" hint="at least 8 characters" required>
          <TextInput value={pw} onChange={setPw} type="password" autoComplete="new-password" placeholder="••••••••" />
        </Field>
        <Field label="I'm here to">
          <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
            {[["learner", "learn"], ["creator", "teach"]].map(([key, label]) => (
              <button
                type="button"
                key={key}
                onClick={() => setRole(key)}
                style={{
                  flex: 1, padding: "14px 18px",
                  border: "1px solid " + (role === key ? "var(--moss)" : "var(--hair-strong)"),
                  background: role === key ? "var(--moss-wash)" : "transparent",
                  color: role === key ? "var(--moss-deep)" : "var(--ink-soft)",
                  borderRadius: 4, fontSize: 14, letterSpacing: "0.02em",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
                  transition: "background 200ms ease, border-color 200ms ease",
                }}
              >
                <Leaf size={12} filled={role === key} strokeWidth={role === key ? 0 : 1.2} /> {label}
              </button>
            ))}
          </div>
        </Field>

        <div style={{ marginTop: 36, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <PrimaryButton onClick={() => { onSignIn && onSignIn(); onNavigate({ name: "library" }); }}>
            plant the first leaf
            <Leaf size={12} strokeWidth={0} tilt={-20} color="var(--moss-soft)" />
          </PrimaryButton>
          <button type="button" onClick={() => onNavigate({ name: "signin" })} style={{ fontSize: 13, color: "var(--ink-soft)" }}>
            already have an account? sign in
          </button>
        </div>

        <p style={{ marginTop: 32, fontSize: 12, color: "var(--ink-faint)", lineHeight: 1.55, maxWidth: 420 }}>
          By creating an account you agree to our quiet terms — no spam, no third-party tracking, and no recommendation engine.
        </p>
      </form>
    </AuthShell>
  );
}

// ---------------------------------------------------------------
// Forgot password
// ---------------------------------------------------------------
function ForgotPasswordScreen({ onNavigate }) {
  const [email, setEmail] = React.useState("");
  const [sent, setSent] = React.useState(false);
  return (
    <AuthShell
      kicker="reset"
      title={sent ? "Letter sent." : "Forgot your password?"}
      intro={sent
        ? "We've sent a reset link to that address. Take a breath. Check your inbox when ready."
        : "Tell us the email you signed up with. We'll send a quiet link to set a new one."}
      side={<AuthLeafComposition progress={sent ? 7 : 3} />}
      onNavigate={onNavigate}
    >
      {!sent ? (
        <form onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
          <Field label="Email" required>
            <TextInput value={email} onChange={setEmail} type="email" placeholder="you@example.com" autoComplete="email" />
          </Field>
          <div style={{ marginTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <PrimaryButton onClick={() => setSent(true)}>send reset link</PrimaryButton>
            <button type="button" onClick={() => onNavigate({ name: "signin" })} style={{ fontSize: 13, color: "var(--ink-soft)" }}>back to sign in</button>
          </div>
        </form>
      ) : (
        <div>
          <div style={{
            display: "flex", alignItems: "center", gap: 14,
            padding: "20px 24px",
            background: "var(--moss-wash)",
            border: "1px solid color-mix(in oklab, var(--moss-soft) 60%, transparent)",
            borderRadius: 4,
            color: "var(--moss-deep)",
            marginBottom: 24,
          }}>
            <Leaf size={18} strokeWidth={0} />
            <div style={{ fontSize: 14 }}>
              A reset link is on its way to <strong style={{ color: "var(--ink)" }}>{email || "your inbox"}</strong>.
            </div>
          </div>
          <GhostButton onClick={() => onNavigate({ name: "signin" })}>back to sign in</GhostButton>
        </div>
      )}
    </AuthShell>
  );
}

// ---------------------------------------------------------------
// Enhanced Profile
// ---------------------------------------------------------------
function ProfileScreen2({ onNavigate, onSignOut }) {
  const tending = COURSES.filter((c) => c.completed > 0 && c.completed < c.lessons);
  const finished = COURSES.filter((c) => c.completed > 0 && c.completed === c.lessons);
  const totalLeaves = COURSES.reduce((s, c) => s + c.completed, 0);

  return (
    <div className="screen" style={{ maxWidth: 1080, margin: "0 auto", padding: "72px 40px 120px" }}>
      <header style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 28, alignItems: "center", paddingBottom: 32, borderBottom: "1px solid var(--hair)" }}>
        <span style={{
          width: 84, height: 84, borderRadius: "50%",
          background: "var(--moss-wash)",
          border: "1px solid var(--hair-strong)",
          display: "grid", placeItems: "center",
          color: "var(--moss-deep)",
        }}>
          <span className="serif" style={{ fontSize: 38, lineHeight: 1 }}>m</span>
        </span>
        <div>
          <div className="mono" style={{ fontSize: 11, letterSpacing: "0.18em", color: "var(--moss)", marginBottom: 8 }}>account · learner</div>
          <h1 className="serif" style={{ margin: 0, fontSize: 48, lineHeight: 1.05, color: "var(--ink)" }}>mira holt</h1>
          <div style={{ marginTop: 8, fontSize: 14, color: "var(--ink-soft)" }}>mira@mindleaf.studio · member since spring '24</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
          <button onClick={() => onNavigate({ name: "createCourse" })} style={{ fontSize: 13, color: "var(--ink-soft)", padding: "10px 14px", border: "1px solid var(--hair-strong)", borderRadius: 4 }}>
            become a teacher
          </button>
          <button onClick={onSignOut} style={{ fontSize: 13, color: "var(--ink-faint)" }}>sign out</button>
        </div>
      </header>

      <section style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 32, padding: "40px 0", borderBottom: "1px solid var(--hair)" }}>
        <Stat label="leaves unfurled" value={String(totalLeaves)} />
        <Stat label="courses tending" value={String(tending.length)} />
        <Stat label="courses finished" value={String(finished.length)} />
        <Stat label="reading minutes" value="412" />
      </section>

      {tending.length > 0 && (
        <section style={{ padding: "56px 0 24px" }}>
          <SectionHeading kicker="currently tending">In progress</SectionHeading>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(360px, 1fr))", gap: 28 }}>
            {tending.map((c) => (
              <article key={c.id} onClick={() => onNavigate({ name: "course", id: c.id })}
                style={{ padding: 28, border: "1px solid var(--hair)", background: "var(--paper-2)", borderRadius: 6, cursor: "pointer" }}>
                <h4 className="serif" style={{ margin: 0, fontSize: 22, marginBottom: 14, color: "var(--ink)" }}>{c.title}</h4>
                <LeafRow total={c.lessons} completed={c.completed} size={14} gap={7} />
                <div style={{ marginTop: 14, display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                  <ProgressLabel completed={c.completed} total={c.lessons} />
                  <span style={{ color: "var(--ink-soft)" }}>continue →</span>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {finished.length > 0 && (
        <section style={{ padding: "32px 0" }}>
          <SectionHeading kicker="finished">Courses you've completed</SectionHeading>
          <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
            {finished.map((c, i) => (
              <li key={c.id}
                  onClick={() => onNavigate({ name: "course", id: c.id })}
                  style={{ display: "grid", gridTemplateColumns: "1fr auto auto", gap: 24, alignItems: "center",
                           padding: "24px 0", borderTop: i === 0 ? "1px solid var(--hair)" : "none",
                           borderBottom: "1px solid var(--hair)", cursor: "pointer" }}>
                <div>
                  <div className="serif" style={{ fontSize: 22, color: "var(--ink)", lineHeight: 1.15 }}>{c.title}</div>
                  <div style={{ fontSize: 13, color: "var(--ink-faint)", marginTop: 4 }}>{c.author} · {c.lessons} lessons</div>
                </div>
                <LeafTag>complete</LeafTag>
                <button onClick={(e) => { e.stopPropagation(); }} style={{ fontSize: 13, color: "var(--ink-soft)" }}>certificate →</button>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", color: "var(--ink-faint)", textTransform: "uppercase", marginBottom: 12 }}>
        {label}
      </div>
      <div className="serif" style={{ fontSize: 36, color: "var(--ink)", lineHeight: 1.05 }}>{value}</div>
    </div>
  );
}

// ---------------------------------------------------------------
// MyCourses — creator dashboard
// ---------------------------------------------------------------
const MY_COURSES = [
  { id: 1, title: "The art of slow reading", state: "published", enrolled: 84, lessons: 8, revenue: null, lastEdit: "3 days ago" },
  { id: 6, title: "Walking as a practice", state: "published", enrolled: 32, lessons: 5, revenue: null, lastEdit: "2 weeks ago" },
  { id: 7, title: "Notes on attention", state: "draft", enrolled: 0, lessons: 4, revenue: null, lastEdit: "yesterday" },
  { id: 8, title: "A small reading list", state: "draft", enrolled: 0, lessons: 3, revenue: null, lastEdit: "1 hour ago" },
];

function MyCoursesScreen({ onNavigate }) {
  const [tab, setTab] = React.useState("all");
  const tabs = [
    { key: "all", label: "all", count: MY_COURSES.length },
    { key: "published", label: "published", count: MY_COURSES.filter((c) => c.state === "published").length },
    { key: "draft", label: "drafts", count: MY_COURSES.filter((c) => c.state === "draft").length },
  ];
  const list = MY_COURSES.filter((c) => tab === "all" ? true : c.state === tab);

  return (
    <div className="screen" style={{ maxWidth: 1180, margin: "0 auto", padding: "72px 40px 120px" }}>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", paddingBottom: 32, borderBottom: "1px solid var(--hair)", marginBottom: 32, gap: 24, flexWrap: "wrap" }}>
        <div>
          <div className="mono" style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 16 }}>
            studio · creator
          </div>
          <h1 className="serif" style={{ margin: 0, fontSize: 56, lineHeight: 1.05, color: "var(--ink)", letterSpacing: "-0.015em" }}>
            Your courses
          </h1>
          <p style={{ margin: 0, marginTop: 12, color: "var(--ink-soft)", maxWidth: 480 }}>
            Two published, two in the soil. Tend to each in their own time.
          </p>
        </div>
        <PrimaryButton onClick={() => onNavigate({ name: "createCourse" })}>
          new course
          <Leaf size={12} strokeWidth={0} color="var(--moss-soft)" />
        </PrimaryButton>
      </div>

      <div style={{ display: "flex", gap: 22, paddingBottom: 14, borderBottom: "1px solid var(--hair)", marginBottom: 24 }}>
        {tabs.map((tb) => (
          <button key={tb.key} onClick={() => setTab(tb.key)}
            style={{
              fontSize: 14, padding: "6px 0",
              color: tab === tb.key ? "var(--ink)" : "var(--ink-soft)",
              borderBottom: "2px solid " + (tab === tb.key ? "var(--moss)" : "transparent"),
              display: "inline-flex", alignItems: "baseline", gap: 8,
            }}>
            {tb.label}
            <span className="mono" style={{ fontSize: 11, color: "var(--ink-faint)" }}>{String(tb.count).padStart(2, "0")}</span>
          </button>
        ))}
      </div>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            {["course", "state", "enrolled", "lessons", "last edited", ""].map((h, i) => (
              <th key={i} className="mono" style={{
                textAlign: i >= 2 && i <= 3 ? "right" : "left",
                fontSize: 10, letterSpacing: "0.16em", textTransform: "uppercase",
                color: "var(--ink-faint)", fontWeight: 400,
                padding: "16px 16px 16px 0", borderBottom: "1px solid var(--hair)",
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {list.map((c) => (
            <tr key={c.id}
              onClick={() => onNavigate({ name: "course", id: c.id })}
              style={{ cursor: "pointer" }}
              onMouseEnter={(e) => { e.currentTarget.style.background = "color-mix(in oklab, var(--moss-wash) 40%, transparent)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}>
              <td style={{ padding: "24px 16px 24px 0", borderBottom: "1px solid var(--hair)" }}>
                <div className="serif" style={{ fontSize: 20, color: "var(--ink)" }}>{c.title}</div>
              </td>
              <td style={{ padding: "24px 16px 24px 0", borderBottom: "1px solid var(--hair)" }}>
                {c.state === "published"
                  ? <LeafTag>published</LeafTag>
                  : <span style={{ fontSize: 11, color: "var(--ink-faint)", padding: "4px 10px", border: "1px solid var(--hair-strong)", borderRadius: 999 }}>draft</span>}
              </td>
              <td className="mono" style={{ padding: "24px 16px 24px 0", borderBottom: "1px solid var(--hair)", textAlign: "right", color: "var(--ink)", fontSize: 14 }}>
                {c.enrolled}
              </td>
              <td className="mono" style={{ padding: "24px 16px 24px 0", borderBottom: "1px solid var(--hair)", textAlign: "right", color: "var(--ink)", fontSize: 14 }}>
                {c.lessons}
              </td>
              <td style={{ padding: "24px 16px 24px 0", borderBottom: "1px solid var(--hair)", color: "var(--ink-soft)", fontSize: 13 }}>
                {c.lastEdit}
              </td>
              <td style={{ padding: "24px 0 24px 16px", borderBottom: "1px solid var(--hair)", textAlign: "right" }}>
                <span style={{ fontSize: 13, color: "var(--ink-soft)" }}>open →</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------
// CreateCourse — a calm form, split into two columns
// ---------------------------------------------------------------
function CreateCourseScreen({ onNavigate }) {
  const [title, setTitle] = React.useState("");
  const [desc, setDesc] = React.useState("");
  const [paid, setPaid] = React.useState(false);
  const [price, setPrice] = React.useState("4900");
  const [season, setSeason] = React.useState("Spring");

  return (
    <div className="screen" style={{ maxWidth: AUTH_MAX, margin: "0 auto", padding: "56px 40px 120px" }}>
      <button onClick={() => onNavigate({ name: "myCourses" })} style={{ color: "var(--ink-soft)", fontSize: 13, marginBottom: 32 }}>← back to your courses</button>

      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 64, alignItems: "flex-start" }}>
        <section>
          <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 18 }}>
            new course
          </div>
          <h1 className="serif" style={{ margin: 0, fontSize: 56, lineHeight: 1.05, color: "var(--ink)", letterSpacing: "-0.015em", marginBottom: 12 }}>
            Plant a course.
          </h1>
          <p style={{ marginTop: 4, marginBottom: 48, color: "var(--ink-soft)", fontSize: 16, lineHeight: 1.6, maxWidth: 480 }}>
            Start with a title and a single sentence. You can add lessons, video, and pdfs later.
          </p>

          <form>
            <Field label="Title" required>
              <TextInput value={title} onChange={setTitle} placeholder="What will you teach?" />
            </Field>
            <Field label="One-sentence description" hint={`${desc.length} / 180`} required>
              <TextInput value={desc} onChange={(v) => setDesc(v.slice(0, 180))} placeholder="A single sentence that says what this course is, and what it is not." />
            </Field>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 28 }}>
              <Field label="Season">
                <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                  {["Spring", "Summer", "Autumn", "Winter"].map((s) => (
                    <button type="button" key={s} onClick={() => setSeason(s)}
                      style={{
                        flex: 1, padding: "8px 6px",
                        border: "1px solid " + (season === s ? "var(--moss)" : "var(--hair-strong)"),
                        background: season === s ? "var(--moss-wash)" : "transparent",
                        color: season === s ? "var(--moss-deep)" : "var(--ink-soft)",
                        borderRadius: 4, fontSize: 12, letterSpacing: "0.02em",
                      }}>{s.toLowerCase()}</button>
                  ))}
                </div>
              </Field>
              <Field label="Tuition">
                <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                  <button type="button" onClick={() => setPaid(false)}
                    style={{
                      flex: 1, padding: "8px 6px",
                      border: "1px solid " + (!paid ? "var(--moss)" : "var(--hair-strong)"),
                      background: !paid ? "var(--moss-wash)" : "transparent",
                      color: !paid ? "var(--moss-deep)" : "var(--ink-soft)",
                      borderRadius: 4, fontSize: 12,
                    }}>free</button>
                  <button type="button" onClick={() => setPaid(true)}
                    style={{
                      flex: 1, padding: "8px 6px",
                      border: "1px solid " + (paid ? "var(--moss)" : "var(--hair-strong)"),
                      background: paid ? "var(--moss-wash)" : "transparent",
                      color: paid ? "var(--moss-deep)" : "var(--ink-soft)",
                      borderRadius: 4, fontSize: 12,
                    }}>paid</button>
                </div>
              </Field>
            </div>

            {paid && (
              <Field label="Price (JPY)" hint="we round to the nearest 100">
                <TextInput value={price} onChange={setPrice} placeholder="4900" />
              </Field>
            )}

            <div style={{ marginTop: 40, display: "flex", gap: 16, alignItems: "center" }}>
              <PrimaryButton onClick={() => onNavigate({ name: "myCourses" })}>
                save and continue
                <Leaf size={12} strokeWidth={0} color="var(--moss-soft)" />
              </PrimaryButton>
              <GhostButton onClick={() => onNavigate({ name: "myCourses" })}>save as draft</GhostButton>
            </div>
          </form>
        </section>

        <aside style={{ padding: 32, background: "var(--paper-2)", border: "1px solid var(--hair)", borderRadius: 6, position: "sticky", top: 96 }}>
          <div className="mono" style={{ fontSize: 11, letterSpacing: "0.18em", color: "var(--ink-faint)", textTransform: "uppercase", marginBottom: 22 }}>
            preview
          </div>
          <div style={{ position: "relative", padding: 24, background: "var(--paper)", border: "1px solid var(--hair)", borderRadius: 6, minHeight: 220 }}>
            <span style={{ position: "absolute", top: 18, right: 18, color: "var(--moss)" }}>
              <Leaf size={18} strokeWidth={0} tilt={-22} />
            </span>
            <div className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ink-faint)", marginBottom: 12 }}>
              {season} · 0 lessons
            </div>
            <h3 className="serif" style={{ fontSize: 22, lineHeight: 1.15, margin: 0, color: title ? "var(--ink)" : "var(--ink-faint)", marginBottom: 8 }}>
              {title || "Your course title"}
            </h3>
            <p style={{ margin: 0, fontSize: 14, color: desc ? "var(--ink-soft)" : "var(--ink-faint)", lineHeight: 1.55 }}>
              {desc || "Your one-sentence description will appear here."}
            </p>
            <div style={{ marginTop: 20, paddingTop: 14, borderTop: "1px solid var(--hair)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 13, color: "var(--ink)" }}>mira holt</span>
              <span className="serif" style={{ fontSize: 16, color: "var(--ink)" }}>
                {paid ? `¥${(parseInt(price || "0", 10) / 100).toFixed(0)}` : "free"}
              </span>
            </div>
          </div>
          <p style={{ marginTop: 20, fontSize: 12, color: "var(--ink-faint)", lineHeight: 1.55 }}>
            This is how your course card will appear in the catalogue. You can edit copy and add a cover image after saving.
          </p>
        </aside>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------
// Users — admin panel
// ---------------------------------------------------------------
const USERS = [
  { name: "mira holt", email: "mira@mindleaf.studio", role: "ADMIN", since: "spring '24", courses: 3, lessons: 21 },
  { name: "ren asano", email: "ren@mindleaf.studio", role: "CREATOR", since: "spring '24", courses: 2, lessons: 13 },
  { name: "jonas vree", email: "jonas@mindleaf.studio", role: "CREATOR", since: "summer '24", courses: 1, lessons: 14 },
  { name: "hiro tanaka", email: "hiro@mindleaf.studio", role: "CREATOR", since: "autumn '24", courses: 1, lessons: 9 },
  { name: "yuna ito", email: "yuna@example.com", role: "STUDENT", since: "autumn '25", courses: 0, lessons: 6 },
  { name: "samuel ord", email: "samuel@example.com", role: "STUDENT", since: "winter '25", courses: 0, lessons: 12 },
  { name: "aki noor", email: "aki@example.com", role: "STUDENT", since: "spring '26", courses: 0, lessons: 2 },
];

function UsersScreen() {
  const [q, setQ] = React.useState("");
  const [filter, setFilter] = React.useState("all");
  const filtered = USERS
    .filter((u) => filter === "all" ? true : u.role === filter.toUpperCase())
    .filter((u) => q ? (u.name.includes(q) || u.email.includes(q)) : true);

  const counts = {
    all: USERS.length,
    student: USERS.filter((u) => u.role === "STUDENT").length,
    creator: USERS.filter((u) => u.role === "CREATOR").length,
    admin: USERS.filter((u) => u.role === "ADMIN").length,
  };

  return (
    <div className="screen" style={{ maxWidth: 1180, margin: "0 auto", padding: "72px 40px 120px" }}>
      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 18 }}>
        studio · admin
      </div>
      <h1 className="serif" style={{ margin: 0, fontSize: 56, lineHeight: 1.05, color: "var(--ink)", letterSpacing: "-0.015em", marginBottom: 12 }}>
        People in the garden.
      </h1>
      <p style={{ marginTop: 4, marginBottom: 40, color: "var(--ink-soft)", fontSize: 16, lineHeight: 1.6, maxWidth: 520 }}>
        Everyone who has joined us, what role they play, and what they've been tending.
      </p>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24, paddingBottom: 16, borderBottom: "1px solid var(--hair)", marginBottom: 8, flexWrap: "wrap" }}>
        <div style={{ display: "flex", gap: 22 }}>
          {[["all", "all"], ["student", "students"], ["creator", "creators"], ["admin", "admins"]].map(([key, label]) => (
            <button key={key} onClick={() => setFilter(key)}
              style={{
                fontSize: 13,
                color: filter === key ? "var(--ink)" : "var(--ink-soft)",
                borderBottom: "2px solid " + (filter === key ? "var(--moss)" : "transparent"),
                padding: "6px 0",
                display: "inline-flex", alignItems: "baseline", gap: 6,
              }}>
              {label}
              <span className="mono" style={{ fontSize: 10, color: "var(--ink-faint)" }}>{String(counts[key]).padStart(2, "0")}</span>
            </button>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 240, borderBottom: "1px solid var(--hair-strong)" }}>
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-faint)" }}>search</span>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="name or email"
            style={{ flex: 1, border: 0, outline: "none", background: "transparent", padding: "8px 0", fontFamily: "DM Sans", fontSize: 14, color: "var(--ink)" }}
          />
        </div>
      </div>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            {["person", "role", "joined", "courses", "lessons", ""].map((h, i) => (
              <th key={i} className="mono" style={{
                textAlign: i >= 3 && i <= 4 ? "right" : "left",
                fontSize: 10, letterSpacing: "0.16em", textTransform: "uppercase",
                color: "var(--ink-faint)", fontWeight: 400,
                padding: "16px 16px 16px 0", borderBottom: "1px solid var(--hair)",
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filtered.map((u, i) => (
            <tr key={u.email}>
              <td style={{ padding: "20px 16px 20px 0", borderBottom: "1px solid var(--hair)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <span style={{
                    width: 36, height: 36, borderRadius: "50%",
                    background: "var(--moss-wash)",
                    border: "1px solid var(--hair)",
                    display: "grid", placeItems: "center",
                    color: "var(--moss-deep)", fontSize: 13,
                  }}>{u.name[0]}</span>
                  <div>
                    <div style={{ fontSize: 14, color: "var(--ink)" }}>{u.name}</div>
                    <div style={{ fontSize: 12, color: "var(--ink-faint)" }}>{u.email}</div>
                  </div>
                </div>
              </td>
              <td style={{ padding: "20px 16px 20px 0", borderBottom: "1px solid var(--hair)" }}>
                <RolePill role={u.role} />
              </td>
              <td style={{ padding: "20px 16px 20px 0", borderBottom: "1px solid var(--hair)", color: "var(--ink-soft)", fontSize: 13 }}>{u.since}</td>
              <td className="mono" style={{ padding: "20px 16px 20px 0", borderBottom: "1px solid var(--hair)", textAlign: "right", color: "var(--ink)", fontSize: 13 }}>{u.courses}</td>
              <td className="mono" style={{ padding: "20px 16px 20px 0", borderBottom: "1px solid var(--hair)", textAlign: "right", color: "var(--ink)", fontSize: 13 }}>{u.lessons}</td>
              <td style={{ padding: "20px 0 20px 16px", borderBottom: "1px solid var(--hair)", textAlign: "right" }}>
                <button style={{ fontSize: 12, color: "var(--ink-soft)", padding: "6px 12px", border: "1px solid var(--hair-strong)", borderRadius: 4 }}>manage</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {filtered.length === 0 && (
        <div style={{ textAlign: "center", padding: "64px 0", color: "var(--ink-faint)" }}>
          <Leaf size={28} strokeWidth={1} />
          <p style={{ marginTop: 14, fontSize: 14 }}>No one matches that search.</p>
        </div>
      )}
    </div>
  );
}

function RolePill({ role }) {
  const map = {
    ADMIN:   { label: "admin",   bg: "color-mix(in oklab, var(--moss-deep) 18%, transparent)", fg: "var(--moss-deep)" },
    CREATOR: { label: "creator", bg: "var(--moss-wash)", fg: "var(--moss-deep)" },
    STUDENT: { label: "student", bg: "transparent", fg: "var(--ink-soft)" },
  };
  const m = map[role] || map.STUDENT;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: "4px 10px", borderRadius: 999,
      background: m.bg, color: m.fg,
      border: "1px solid " + (role === "STUDENT" ? "var(--hair-strong)" : "color-mix(in oklab, var(--moss-soft) 60%, transparent)"),
      fontSize: 11, letterSpacing: "0.04em",
    }}>
      {role !== "STUDENT" && <Leaf size={9} strokeWidth={0} />}
      {m.label}
    </span>
  );
}

// ---------------------------------------------------------------
// Payment success / cancel
// ---------------------------------------------------------------
function PaymentSuccessScreen({ onNavigate, courseId = 3 }) {
  const course = COURSES.find((c) => c.id === courseId) || COURSES[2];
  return (
    <div className="screen" style={{ maxWidth: 760, margin: "0 auto", padding: "120px 40px", textAlign: "center", position: "relative" }}>
      <div style={{ display: "inline-block", marginBottom: 36 }}>
        {/* a small composition: a stem with all leaves filled */}
        <svg width="120" height="160" viewBox="0 0 120 160" style={{ overflow: "visible" }}>
          <line x1="60" y1="8" x2="60" y2="150" stroke="var(--moss)" strokeWidth="2" strokeLinecap="round" />
          <circle cx="60" cy="8" r="4" fill="var(--moss)" />
          {[24, 50, 76, 102, 128].map((y, i) => {
            const s = i % 2 === 0 ? -1 : 1;
            return (
              <g key={i}>
                <path d={`M 60 ${y} Q ${60 + s * 8} ${y + 1} ${60 + s * 22} ${y - 6}`}
                      stroke="var(--moss)" strokeWidth="1.4" fill="none" strokeLinecap="round" />
                <g transform={`translate(${60 + s * 22} ${y - 6}) rotate(${s * 70}) scale(1.2)`}>
                  <path d="M0 0 C -7 -3, -10 -10, 0 -16 C 10 -10, 7 -3, 0 0 Z" fill="var(--moss)" />
                  <path d="M0 0 V -15" stroke="var(--paper-2)" strokeWidth="0.8" opacity="0.55" />
                </g>
              </g>
            );
          })}
        </svg>
      </div>

      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--moss)", marginBottom: 22 }}>
        payment received
      </div>
      <h1 className="serif" style={{ margin: 0, fontSize: 56, lineHeight: 1.05, letterSpacing: "-0.018em", color: "var(--ink)", marginBottom: 20 }}>
        You're enrolled.
      </h1>
      <p style={{ margin: 0, fontSize: 17, color: "var(--ink-soft)", lineHeight: 1.65, maxWidth: 520, marginInline: "auto" }}>
        Thank you for joining <span className="serif" style={{ color: "var(--ink)" }}>{course.title}</span>. A receipt is on its way to your inbox. The first lesson is ready when you are.
      </p>

      <div style={{ marginTop: 44, display: "flex", justifyContent: "center", gap: 14, flexWrap: "wrap" }}>
        <PrimaryButton onClick={() => onNavigate({ name: "course", id: course.id })}>
          begin the course
          <Leaf size={12} strokeWidth={0} color="var(--moss-soft)" />
        </PrimaryButton>
        <GhostButton onClick={() => onNavigate({ name: "library" })}>go to your library</GhostButton>
      </div>

      <div style={{ marginTop: 56, paddingTop: 32, borderTop: "1px solid var(--hair)", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24, textAlign: "left", maxWidth: 520, marginInline: "auto" }}>
        <Receipt label="course" value={course.title} />
        <Receipt label="paid" value="¥4,900" />
        <Receipt label="reference" value="ml-7a3-bx" mono />
      </div>
    </div>
  );
}

function Receipt({ label, value, mono }) {
  return (
    <div>
      <div className="mono" style={{ fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--ink-faint)", marginBottom: 6 }}>{label}</div>
      <div className={mono ? "mono" : "serif"} style={{ fontSize: mono ? 14 : 17, color: "var(--ink)", lineHeight: 1.2 }}>{value}</div>
    </div>
  );
}

function PaymentCancelScreen({ onNavigate, courseId = 3 }) {
  const course = COURSES.find((c) => c.id === courseId) || COURSES[2];
  return (
    <div className="screen" style={{ maxWidth: 760, margin: "0 auto", padding: "120px 40px", textAlign: "center" }}>
      <div style={{ display: "inline-block", marginBottom: 36, opacity: 0.5 }}>
        <svg width="120" height="160" viewBox="0 0 120 160" style={{ overflow: "visible" }}>
          <line x1="60" y1="8" x2="60" y2="150" stroke="var(--hair-strong)" strokeWidth="1.5" strokeLinecap="round" strokeDasharray="3 4" />
          {[40, 80, 120].map((y, i) => {
            const s = i % 2 === 0 ? -1 : 1;
            return (
              <g key={i}>
                <path d={`M 60 ${y} Q ${60 + s * 8} ${y + 1} ${60 + s * 22} ${y - 6}`}
                      stroke="var(--ink-faint)" strokeWidth="1" fill="none" strokeLinecap="round" opacity="0.6" />
                <g transform={`translate(${60 + s * 22} ${y - 6}) rotate(${s * 70}) scale(1.1)`}>
                  <path d="M0 0 C -7 -3, -10 -10, 0 -16 C 10 -10, 7 -3, 0 0 Z"
                        fill="none" stroke="var(--ink-faint)" strokeWidth="1.2" opacity="0.7" />
                </g>
              </g>
            );
          })}
        </svg>
      </div>

      <div className="mono" style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--ink-faint)", marginBottom: 22 }}>
        payment not completed
      </div>
      <h1 className="serif" style={{ margin: 0, fontSize: 56, lineHeight: 1.05, letterSpacing: "-0.018em", color: "var(--ink)", marginBottom: 20 }}>
        No leaves planted.
      </h1>
      <p style={{ margin: 0, fontSize: 17, color: "var(--ink-soft)", lineHeight: 1.65, maxWidth: 520, marginInline: "auto" }}>
        Your card was not charged. <span className="serif" style={{ color: "var(--ink)" }}>{course.title}</span> is still waiting whenever you'd like to begin.
      </p>

      <div style={{ marginTop: 44, display: "flex", justifyContent: "center", gap: 14, flexWrap: "wrap" }}>
        <PrimaryButton onClick={() => onNavigate({ name: "course", id: course.id })}>
          try again
        </PrimaryButton>
        <GhostButton onClick={() => onNavigate({ name: "courses" })}>back to catalogue</GhostButton>
      </div>
    </div>
  );
}

Object.assign(window, {
  SignInScreen, RegisterScreen, ForgotPasswordScreen,
  ProfileScreen2, MyCoursesScreen, CreateCourseScreen, UsersScreen,
  PaymentSuccessScreen, PaymentCancelScreen,
});
