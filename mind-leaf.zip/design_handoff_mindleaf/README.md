# Handoff: mindleaf — leafy redesign

## Overview

This package redesigns the **mindleaf** course-hosting frontend (React + Vite +
Tailwind, in `course-hosting-frontend/`) around a calm, **Japanese-garden / zen**
aesthetic: washi-paper background, sumi-ink text, a single moss-green accent, and
one recurring motif — a **leaf** — used at every scale. The headline UX idea is a
**growing-plant progress metaphor**: every lesson is a leaf that unfurls on a stem
as you complete it. No streaks, no gradients, no box-shadows — hairline borders and
generous whitespace instead.

The redesign is **visual only**. It does not change routes, API calls, state logic,
auth, or data shapes. Your job is to restyle the existing components and add the
shared leaf primitives — not to rewrite behavior.

## About the design files

Everything in `design-reference/` is an **HTML/React prototype** built to show the
intended look and behavior. It runs standalone in a browser (open `mindleaf.html`),
uses mock data, and renders all screens with a Tweaks panel for theme/density/accent.

**It is a design reference, not code to ship.** The real app is the React/Vite
project in `course-hosting-frontend/`. Your task is to **recreate this design inside
that existing codebase** using its established patterns (React Router, the `useAuth`
context, the `*Api` modules in `src/api/api.js`, Tailwind). Do not paste prototype
files into the app — port the *look* onto the *existing components*.

Two folders give you a head start:

- **`ready-to-use/`** — files you can drop in nearly verbatim:
  - `src/index.css` — design tokens (CSS variables) + reusable classes + dark mode.
  - `tailwind.config.js` — font families, color aliases (`text-ink`, `bg-paper`,
    `border-hair`, …), `darkMode: 'class'`.
  - `src/components/Leaf.jsx` — **the design system in code**: `Leaf`, `BrandLeaf`,
    `LeafRow`, `GrowingStem`, `MiniStem`, plus `Kicker`, `SectionHeading`, `LeafTag`,
    `Field`. Import these everywhere.
- **`reference-ports/`** — `App.jsx`, `Home.jsx`, `Courses.jsx`, `CourseDetail.jsx`
  already ported to the new look against the **real** API signatures. Treat these as
  worked examples / strong starting points — diff them against the live files and
  adapt. They were written from the real source, but **verify every import and API
  call against your tree and run the build** before trusting them.

## Fidelity

**High-fidelity.** Colors, typography, spacing, and interactions are final. Match
them precisely using the tokens in `ready-to-use/src/index.css`. Where a screen in
the prototype is richer than the current app (e.g. the growing-stem sidebar on course
detail), implement the prototype's version.

---

## Setup (do this first)

1. **Fonts.** Add to `course-hosting-frontend/index.html` `<head>`:
   ```html
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Shippori+Mincho:wght@400;500;600;700&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@300;400;500&display=swap" rel="stylesheet">
   ```
2. **Tokens & Tailwind.** Replace `src/index.css` and `tailwind.config.js` with the
   versions in `ready-to-use/`. Note `darkMode: 'class'` — dark mode is toggled by
   adding `.dark` to `<html>`.
3. **Leaf primitives.** Copy `ready-to-use/src/components/Leaf.jsx` into
   `src/components/Leaf.jsx`.
4. `npm install` (no new dependencies) and `npm run dev`. Confirm the app compiles and
   fonts load before restyling anything.
5. Port components one at a time, following `COMPONENT_GUIDE.md`. After each, verify
   the page renders and its API calls still work.

---

## Design tokens

All defined as CSS variables in `ready-to-use/src/index.css`. Light values / dark
values:

| Token            | Light       | Dark        | Use                                   |
|------------------|-------------|-------------|---------------------------------------|
| `--paper`        | `#f6f3ea`   | `#11140f`   | page background                       |
| `--paper-2`      | `#efeadd`   | `#181c15`   | cards, panels, insets                 |
| `--ink`          | `#1a1d18`   | `#e9e8df`   | primary text, primary buttons         |
| `--ink-soft`     | `#4a4d44`   | `#b8b8a8`   | body copy                             |
| `--ink-faint`    | `#8a8a7e`   | `#6e7166`   | meta, captions, kickers               |
| `--hair`         | `rgba(26,29,24,.10)` | `rgba(233,232,223,.10)` | hairline borders (default) |
| `--hair-strong`  | `rgba(26,29,24,.22)` | `rgba(233,232,223,.22)` | input underlines, dividers |
| `--moss`         | `#4a6b3f`   | `#9bb787`   | the one accent — leaves, active state |
| `--moss-deep`    | `#34522c`   | `#b9d0a5`   | accent text on wash, emphasis         |
| `--moss-soft`    | `#b7c4a4`   | `#3a4a32`   | leaf-on-dark, borders                 |
| `--moss-wash`    | `#e8ecd9`   | `#1c2418`   | pill/badge/active-row background      |
| `--gold`         | `#b08a3e`   | `#d6b365`   | reserved (paid-course marker), rare   |

**Accent is themeable.** The prototype offers moss / forest / sage / olive. Ship
**moss** as default; the others are optional. If you support them, set the four
`--moss*` variables from a palette object (see `app.jsx` `ACCENT_PALETTES` in the
design reference).

### Type
- **Display / headings** — `Shippori Mincho` (Tailwind `font-serif`), weight 500.
  Large, tight tracking (`-0.015em` to `-0.02em`).
- **Body / UI** — `DM Sans` (default, `font-sans`).
- **Kickers / meta / numbers** — `DM Mono` (`font-mono`), 11px, uppercase,
  letter-spacing `0.14–0.22em`. This is the signature "label" style — use the
  `Kicker` component or `.ml-kicker` class.

### Shape & depth
- Border radius: **4px** buttons/inputs, **6px** cards. Never large/pill except the
  small `.ml-pill` badges (999px) and avatars (50%).
- **No box-shadows.** Depth comes from hairline borders + whitespace. Hover = border
  goes from `--hair` to `--hair-strong` (or a subtle `--moss-wash` row tint in lists).
- Lots of air. Section padding 72–120px vertical. Page max-width **1180px**
  (`max-w-page`).

### Motion
- Screen/route enter: `ml-screen-fade` (360ms, translateY 4px → 0).
- Hover transitions 180–220ms ease. Theme toggle knob slides 220ms.

---

## The leaf system (read this before building)

One SVG leaf path, reused everywhere. Canonical path (24×24 viewBox):
`M12 2 C 5 8, 5 17, 12 22 C 19 17, 19 8, 12 2 Z` with a center vein `M12 4 V 21`.
Filled = active/done; outlined = pending. All of this is implemented in
`ready-to-use/src/components/Leaf.jsx`:

| Component       | Where it's used                                                        |
|-----------------|------------------------------------------------------------------------|
| `Leaf`          | inline glyph anywhere (nav, buttons, list bullets, scatter)            |
| `BrandLeaf`     | the wordmark mark in nav + footer                                      |
| `LeafRow`       | **horizontal** progress — leaves on a connecting vine. Cards, lists.   |
| `GrowingStem`   | **vertical** progress — the hero metaphor on Course Detail sidebar.    |
| `MiniStem`      | compact 80×100 stem for thumbnails (library/profile cards)             |
| `Kicker`        | the mono uppercase label                                               |
| `SectionHeading`| leaf kicker + serif H2                                                  |
| `LeafTag`       | small moss pill with a leaf (status: "tending", "published", …)        |

**Critical detail (this was an explicit revision):** in `LeafRow`, `GrowingStem`, and
`MiniStem` the leaves are **physically connected to the stem** — each leaf attaches via
a short petiole (a `<line>` or quadratic `<path>` from the stem to the leaf base), and
the stem itself has a faint full-length track plus a moss "grown" segment up to the
last completed leaf, tipped with a small bud `<circle>`. Do not render leaves as
free-floating icons in a fl/ex row. Keep the single-SVG, petiole-attached approach.

`LeafRow` and `GrowingStem` accept an `onLeafClick` / `onJump` callback so a leaf can
navigate to (or select) its lesson.

---

## Screens

Detailed, per-file porting notes — props, API calls, role logic, exact copy — are in
**`COMPONENT_GUIDE.md`**. High-level map:

| Route                              | File                      | Redesign summary |
|------------------------------------|---------------------------|------------------|
| `/`                                | `Home.jsx`                | Quiet hero (huge serif headline, one giant faint leaf), 3 principles, featured-course card. ✅ ported in `reference-ports/`. |
| `/courses`                         | `Courses.jsx`            | Editorial header + count, single-line filter bar (all/free/studio) with leaf marker, hairline card grid. Card keeps Stripe/PayPal/enroll buttons. ✅ ported. |
| `/courses/:id`                     | `CourseDetail.jsx`        | **The showcase.** Two-column header (title + tuition/enroll), then a sticky **GrowingStem** sidebar beside the lesson list; each lesson row has a leaf that fills on completion. ✅ ported. |
| `/courses/:id/lessons/:lessonId`   | `LessonView.jsx`          | Reading-room: 16:9 video panel placeholder, big serif title, `LeafRow` header showing course progress, mark-complete button, PDF-notes row. (Not pre-ported — see guide + prototype `LessonScreen`.) |
| `/login`                           | `Login.jsx`               | Split `AuthShell`: form left, leaf composition right. Underlined-input style. |
| `/register`                        | `Register.jsx`            | Same shell; keep name/email/password/confirm + validation. Learner/teacher segmented control is decorative unless your API supports it. |
| `/forgot-password`                 | `ForgotPassword.jsx`      | Same shell; submitted-state shows a moss confirowation panel. |
| `/profile`                         | `Profile.jsx`             | Avatar + stats row (leaves unfurled / tending / finished / minutes), in-progress cards with `LeafRow`, finished list with `LeafTag`. Keep verify-email banner, unenroll, progress modal. |
| `/my-courses`                      | `MyCourses.jsx`           | Creator dashboard: published/drafts tabs, hairline table. Keep all management (reorder, pricing, access, delete). |
| `/courses/create`                  | `CreateCourse.jsx`        | Two-column: calm form left, **live preview card** right. Keep pricing + allowlist fields. |
| `/users`                           | `Users.jsx`               | Admin table restyled with `RolePill`, avatar initials, search/filter. Keep upgrade/reset/delete actions. |
| `/payment/success`                 | `PaymentSuccess.jsx`      | Replace 🎉 with a full-grown stem (all leaves filled). Keep capturing/loading/enrolled/pending/error states + polling. |
| `/payment/cancel`                  | `PaymentCancel.jsx`       | "No leaves planted" — a dashed, empty stem (outlined leaves). Keep retry links. |

Not restyled (lower priority, same patterns): `Lessons.jsx`, `CreateLesson.jsx`,
`EditLesson.jsx`, `ResetPassword.jsx`, `VerifyEmail.jsx`. Apply the same tokens when
you get to them.

---

## Interactions & behavior (unchanged from current app)

Preserve all existing behavior. Key things the redesign must **not** break:

- **Auth/roles** via `useAuth()` → `{ user, isAuthenticated, login, logout, refreshUser }`.
  Role gates: `user?.role` ∈ `STUDENT | CREATOR | ADMIN`. Studio nav only for
  CREATOR/ADMIN; people/users only for ADMIN.
- **Payments**: `Courses` and `CourseDetail` call `paymentsApi.createCheckoutSession`
  (Stripe) and `paymentsApi.createPaypalOrder` (PayPal), stash
  `sessionStorage.stripeCheckout = { courseId }`, then redirect. `PaymentSuccess`
  reads `session_id` (Stripe) or `token` (PayPal), captures/polls
  `paymentsApi.getPaymentStatus` up to 10× every 2s. Keep all of it.
- **Enrollment/progress**: `enrollmentApi.enrollInCourse / getMyCourses /
  completeLesson / getCourseProgress / unenrollFromCourse`. `completeLesson` also calls
  `playCompletionSound()` (`src/utils/sound.js`) — keep it; it pairs perfectly with a
  leaf unfurling.
- **Price formatting**: `formatPrice(priceCents, currency)` from `src/utils/pricing.js`
  (GBP/USD/EUR — note: **not** JPY; the prototype's ¥ is mock only). `CURRENCY_OPTIONS`
  for selects.
- Error/loading/empty states stay; restyle them (spinners → a small `<Leaf>` mark or a
  hairline; red alert boxes → keep semantics, soften to the paper palette).

---

## State management

No new global state. The dark-mode toggle is the only addition: store `'dark'|'light'`
in `localStorage.theme`, toggle `.dark` on `document.documentElement`, default to
`prefers-color-scheme`. `reference-ports/App.jsx` implements this in the nav.

---

## Assets

- **No image assets** ship with this redesign — the leaf is all SVG (inline, themeable
  via `currentColor` / CSS vars).
- Course cover images are **placeholder slots** in the prototype (a diagonal-hatch fill
  with a faint leaf). If/when the backend provides cover URLs, drop them into the same
  slot; otherwise keep the placeholder.
- Fonts load from Google Fonts (see Setup). If you self-host, keep the same families
  and weights.

---

## Files in this package

```
design_handoff_mindleaf/
├── README.md                      ← you are here
├── COMPONENT_GUIDE.md             ← per-file porting instructions (read next)
├── design-reference/              ← the runnable HTML prototype (DESIGN REFERENCE ONLY)
│   ├── mindleaf.html              ← open this in a browser to see every screen
│   ├── data.jsx  components.jsx  screens.jsx  screens-auth.jsx  app.jsx
│   └── tweaks-panel.jsx
├── ready-to-use/                  ← drop into the real app nearly verbatim
│   ├── tailwind.config.js
│   └── src/
│       ├── index.css
│       └── components/Leaf.jsx
└── reference-ports/               ← worked examples, ported against the REAL api.js
    ├── App.jsx  Home.jsx  Courses.jsx  CourseDetail.jsx
```

**Verify before trusting `reference-ports/`:** they were written from the real source
in this session but not executed. Check imports (`../context/AuthContext`,
`../api/api`, `../utils/pricing`, `../utils/sound`), confirm field names on API
responses, and run `npm run dev`. The prototype in `design-reference/` is the
authoritative *visual* spec; the live app is the authoritative *behavioral* spec.
